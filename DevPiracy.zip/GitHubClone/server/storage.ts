import { users, repositories, files, commits, issues, pullRequests, comments, stars, followers } from "@shared/schema";
import type { User, InsertUser, Repository, InsertRepository, File, InsertFile, Commit, InsertCommit, Issue, InsertIssue, PullRequest, InsertPullRequest, Comment, InsertComment, Star, InsertStar, Follower, InsertFollower } from "@shared/schema";
import { db } from "./db";
import { eq, and, or, like, desc, sql, isNull } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // Repository methods
  getRepository(id: number): Promise<Repository | undefined>;
  getRepositoryByUserAndName(userId: number, name: string): Promise<Repository | undefined>;
  getUserRepositories(userId: number): Promise<Repository[]>;
  createRepository(repo: InsertRepository): Promise<Repository>;
  updateRepository(id: number, repoData: Partial<InsertRepository>): Promise<Repository | undefined>;
  deleteRepository(id: number): Promise<boolean>;
  searchRepositories(query: string): Promise<Repository[]>;
  getForkCount(repositoryId: number): Promise<number>;
  
  // File methods
  getFile(id: number): Promise<File | undefined>;
  getFileByPath(repositoryId: number, path: string): Promise<File | undefined>;
  getRepositoryFiles(repositoryId: number): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  updateFile(id: number, fileData: Partial<InsertFile>): Promise<File | undefined>;
  deleteFile(id: number): Promise<boolean>;
  
  // Commit methods
  getCommit(id: number): Promise<Commit | undefined>;
  getRepositoryCommits(repositoryId: number): Promise<Commit[]>;
  createCommit(commit: InsertCommit): Promise<Commit>;
  
  // Issue methods
  getIssue(id: number): Promise<Issue | undefined>;
  getRepositoryIssues(repositoryId: number): Promise<Issue[]>;
  createIssue(issue: InsertIssue): Promise<Issue>;
  updateIssue(id: number, issueData: Partial<InsertIssue>): Promise<Issue | undefined>;
  
  // Pull request methods
  getPullRequest(id: number): Promise<PullRequest | undefined>;
  getRepositoryPullRequests(repositoryId: number): Promise<PullRequest[]>;
  createPullRequest(pr: InsertPullRequest): Promise<PullRequest>;
  updatePullRequest(id: number, prData: Partial<InsertPullRequest>): Promise<PullRequest | undefined>;
  
  // Comment methods
  getIssueComments(issueId: number): Promise<Comment[]>;
  getPullRequestComments(prId: number): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  
  // Star methods
  getRepositoryStars(repositoryId: number): Promise<Star[]>;
  getUserStarredRepositories(userId: number): Promise<Repository[]>;
  getStarCount(repositoryId: number): Promise<number>;
  starRepository(userId: number, repositoryId: number): Promise<Star>;
  unstarRepository(userId: number, repositoryId: number): Promise<boolean>;
  hasUserStarredRepository(userId: number, repositoryId: number): Promise<boolean>;
  
  // Follower methods
  getFollowers(userId: number): Promise<User[]>;
  getFollowing(userId: number): Promise<User[]>;
  getFollowerCount(userId: number): Promise<number>;
  getFollowingCount(userId: number): Promise<number>;
  followUser(followerId: number, followingId: number): Promise<Follower>;
  unfollowUser(followerId: number, followingId: number): Promise<boolean>;
  isFollowing(followerId: number, followingId: number): Promise<boolean>;
  
  // Session store
  sessionStore: any; // Use any type to avoid session.SessionStore issues
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ pool, createTableIfMissing: true });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [updatedUser] = await db.update(users).set(userData).where(eq(users.id, id)).returning();
    return updatedUser;
  }

  // Repository methods
  async getRepository(id: number): Promise<Repository | undefined> {
    const [repository] = await db.select().from(repositories).where(eq(repositories.id, id));
    return repository;
  }

  async getRepositoryByUserAndName(userId: number, name: string): Promise<Repository | undefined> {
    const [repository] = await db.select().from(repositories)
      .where(and(eq(repositories.userId, userId), eq(repositories.name, name)));
    return repository;
  }

  async getUserRepositories(userId: number): Promise<Repository[]> {
    return db.select().from(repositories).where(eq(repositories.userId, userId)).orderBy(desc(repositories.createdAt));
  }

  async createRepository(repo: InsertRepository): Promise<Repository> {
    const [newRepo] = await db.insert(repositories).values(repo).returning();
    return newRepo;
  }

  async updateRepository(id: number, repoData: Partial<InsertRepository>): Promise<Repository | undefined> {
    const [updatedRepo] = await db.update(repositories).set(repoData).where(eq(repositories.id, id)).returning();
    return updatedRepo;
  }

  async deleteRepository(id: number): Promise<boolean> {
    const result = await db.delete(repositories).where(eq(repositories.id, id)).returning({ id: repositories.id });
    return result.length > 0;
  }

  async searchRepositories(query: string): Promise<Repository[]> {
    return db.select().from(repositories)
      .where(or(
        like(repositories.name, `%${query}%`),
        like(repositories.description, `%${query}%`)
      ))
      .orderBy(desc(repositories.createdAt));
  }

  async getForkCount(repositoryId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(repositories)
      .where(eq(repositories.forkedFromId, repositoryId));
    return result[0].count;
  }

  // File methods
  async getFile(id: number): Promise<File | undefined> {
    const [file] = await db.select().from(files).where(eq(files.id, id));
    return file;
  }

  async getFileByPath(repositoryId: number, path: string): Promise<File | undefined> {
    const [file] = await db.select().from(files)
      .where(and(eq(files.repositoryId, repositoryId), eq(files.path, path)));
    return file;
  }

  async getRepositoryFiles(repositoryId: number): Promise<File[]> {
    return db.select().from(files).where(eq(files.repositoryId, repositoryId));
  }

  async createFile(file: InsertFile): Promise<File> {
    const [newFile] = await db.insert(files).values(file).returning();
    return newFile;
  }

  async updateFile(id: number, fileData: Partial<InsertFile>): Promise<File | undefined> {
    const [updatedFile] = await db.update(files).set(fileData).where(eq(files.id, id)).returning();
    return updatedFile;
  }

  async deleteFile(id: number): Promise<boolean> {
    const result = await db.delete(files).where(eq(files.id, id)).returning({ id: files.id });
    return result.length > 0;
  }

  // Commit methods
  async getCommit(id: number): Promise<Commit | undefined> {
    const [commit] = await db.select().from(commits).where(eq(commits.id, id));
    return commit;
  }

  async getRepositoryCommits(repositoryId: number): Promise<Commit[]> {
    return db.select().from(commits)
      .where(eq(commits.repositoryId, repositoryId))
      .orderBy(desc(commits.createdAt));
  }

  async createCommit(commit: InsertCommit): Promise<Commit> {
    const [newCommit] = await db.insert(commits).values(commit).returning();
    return newCommit;
  }

  // Issue methods
  async getIssue(id: number): Promise<Issue | undefined> {
    const [issue] = await db.select().from(issues).where(eq(issues.id, id));
    return issue;
  }

  async getRepositoryIssues(repositoryId: number): Promise<Issue[]> {
    return db.select().from(issues)
      .where(eq(issues.repositoryId, repositoryId))
      .orderBy(desc(issues.createdAt));
  }

  async createIssue(issue: InsertIssue): Promise<Issue> {
    const [newIssue] = await db.insert(issues).values(issue).returning();
    return newIssue;
  }

  async updateIssue(id: number, issueData: Partial<InsertIssue>): Promise<Issue | undefined> {
    const [updatedIssue] = await db.update(issues).set(issueData).where(eq(issues.id, id)).returning();
    return updatedIssue;
  }

  // Pull request methods
  async getPullRequest(id: number): Promise<PullRequest | undefined> {
    const [pr] = await db.select().from(pullRequests).where(eq(pullRequests.id, id));
    return pr;
  }

  async getRepositoryPullRequests(repositoryId: number): Promise<PullRequest[]> {
    return db.select().from(pullRequests)
      .where(eq(pullRequests.repositoryId, repositoryId))
      .orderBy(desc(pullRequests.createdAt));
  }

  async createPullRequest(pr: InsertPullRequest): Promise<PullRequest> {
    const [newPr] = await db.insert(pullRequests).values(pr).returning();
    return newPr;
  }

  async updatePullRequest(id: number, prData: Partial<InsertPullRequest>): Promise<PullRequest | undefined> {
    const [updatedPr] = await db.update(pullRequests).set(prData).where(eq(pullRequests.id, id)).returning();
    return updatedPr;
  }

  // Comment methods
  async getIssueComments(issueId: number): Promise<Comment[]> {
    return db.select().from(comments)
      .where(eq(comments.issueId, issueId))
      .orderBy(comments.createdAt);
  }

  async getPullRequestComments(prId: number): Promise<Comment[]> {
    return db.select().from(comments)
      .where(eq(comments.pullRequestId, prId))
      .orderBy(comments.createdAt);
  }

  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db.insert(comments).values(comment).returning();
    return newComment;
  }

  // Star methods
  async getRepositoryStars(repositoryId: number): Promise<Star[]> {
    return db.select().from(stars).where(eq(stars.repositoryId, repositoryId));
  }

  async getUserStarredRepositories(userId: number): Promise<Repository[]> {
    return db.select().from(repositories)
      .innerJoin(stars, eq(repositories.id, stars.repositoryId))
      .where(eq(stars.userId, userId))
      .orderBy(desc(stars.createdAt))
      .then(rows => rows.map(row => row.repositories));
  }

  async getStarCount(repositoryId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(stars)
      .where(eq(stars.repositoryId, repositoryId));
    return result[0].count;
  }

  async starRepository(userId: number, repositoryId: number): Promise<Star> {
    const [star] = await db.insert(stars).values({ userId, repositoryId }).returning();
    return star;
  }

  async unstarRepository(userId: number, repositoryId: number): Promise<boolean> {
    const result = await db.delete(stars)
      .where(and(eq(stars.userId, userId), eq(stars.repositoryId, repositoryId)))
      .returning({ userId: stars.userId });
    return result.length > 0;
  }

  async hasUserStarredRepository(userId: number, repositoryId: number): Promise<boolean> {
    const [star] = await db.select().from(stars)
      .where(and(eq(stars.userId, userId), eq(stars.repositoryId, repositoryId)));
    return !!star;
  }

  // Follower methods
  async getFollowers(userId: number): Promise<User[]> {
    const result = await db.select().from(users)
      .innerJoin(followers, eq(users.id, followers.followerId))
      .where(eq(followers.followingId, userId));
    return result.map(row => row.users);
  }

  async getFollowing(userId: number): Promise<User[]> {
    const result = await db.select().from(users)
      .innerJoin(followers, eq(users.id, followers.followingId))
      .where(eq(followers.followerId, userId));
    return result.map(row => row.users);
  }

  async getFollowerCount(userId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(followers)
      .where(eq(followers.followingId, userId));
    return result[0].count;
  }

  async getFollowingCount(userId: number): Promise<number> {
    const result = await db.select({ count: sql<number>`count(*)` })
      .from(followers)
      .where(eq(followers.followerId, userId));
    return result[0].count;
  }

  async followUser(followerId: number, followingId: number): Promise<Follower> {
    const [follow] = await db.insert(followers).values({ followerId, followingId }).returning();
    return follow;
  }

  async unfollowUser(followerId: number, followingId: number): Promise<boolean> {
    const result = await db.delete(followers)
      .where(and(eq(followers.followerId, followerId), eq(followers.followingId, followingId)))
      .returning({ followerId: followers.followerId });
    return result.length > 0;
  }

  async isFollowing(followerId: number, followingId: number): Promise<boolean> {
    const [follow] = await db.select().from(followers)
      .where(and(eq(followers.followerId, followerId), eq(followers.followingId, followingId)));
    return !!follow;
  }
}

export const storage = new DatabaseStorage();
