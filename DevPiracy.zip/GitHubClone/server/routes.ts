import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertRepositorySchema, insertFileSchema, insertCommitSchema, insertIssueSchema, insertPullRequestSchema, insertCommentSchema } from "@shared/schema";
import { WebSocketServer } from "ws";

// Helper middleware to check if user is authenticated
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  const httpServer = createServer(app);
  
  // Comment out the WebSocket server temporarily to avoid conflicts with Vite
  /*
  const wss = new WebSocketServer({ 
    server: httpServer,
    perMessageDeflate: false,
    path: '/ws/notifications' // Use a specific path to avoid conflicts with Vite HMR
  });
  
  wss.on('connection', (ws) => {
    console.log('Notification WebSocket client connected');
    
    ws.on('message', (message) => {
      try {
        const msg = message.toString();
        console.log('Received notification: %s', msg);
      } catch (error) {
        console.error('Failed to process WebSocket message:', error);
      }
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
    
    ws.on('close', () => {
      console.log('Notification WebSocket client disconnected');
    });
  });
  
  wss.on('error', (error) => {
    console.error('WebSocket server error:', error);
  });
  */

  // User routes
  app.get("/api/users/:username", async (req, res) => {
    try {
      // Special handling for routes like /api/users/explore or /api/users/settings
      if (req.params.username === 'explore' || req.params.username === 'settings') {
        // For these special routes, we'll return the current user's data instead
        if (req.isAuthenticated()) {
          const { password, ...userWithoutPassword } = req.user!;
          return res.json(userWithoutPassword);
        } else {
          return res.status(401).json({ message: "Unauthorized" });
        }
      }
      
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      // Don't return password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.patch("/api/user", isAuthenticated, async (req, res) => {
    try {
      const updateSchema = z.object({
        bio: z.string().optional(),
        location: z.string().optional(),
        website: z.string().optional(),
        email: z.string().email().optional(),
      });

      const validData = updateSchema.parse(req.body);
      const updatedUser = await storage.updateUser(req.user!.id, validData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Repository routes
  app.get("/api/repositories", async (req, res) => {
    try {
      const { q } = req.query;
      
      if (q && typeof q === 'string') {
        const repositories = await storage.searchRepositories(q);
        return res.json(repositories);
      }
      
      if (req.isAuthenticated()) {
        const repositories = await storage.getUserRepositories(req.user!.id);
        return res.json(repositories);
      }
      
      res.status(400).json({ message: "Missing search query" });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/users/:username/repositories", async (req, res) => {
    try {
      // Special handling for routes like /explore and /settings
      if (req.params.username === 'explore' || req.params.username === 'settings') {
        if (req.isAuthenticated()) {
          const repositories = await storage.getUserRepositories(req.user!.id);
          return res.json(repositories);
        } else {
          return res.status(401).json({ message: "Unauthorized" });
        }
      }
      
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const repositories = await storage.getUserRepositories(user.id);
      res.json(repositories);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  // Add followers/following routes
  app.get("/api/users/:username/followers", async (req, res) => {
    try {
      // Special handling for routes like /explore and /settings
      if (req.params.username === 'explore' || req.params.username === 'settings') {
        if (req.isAuthenticated()) {
          const followers = await storage.getFollowers(req.user!.id);
          return res.json(followers);
        } else {
          return res.status(401).json({ message: "Unauthorized" });
        }
      }
      
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const followers = await storage.getFollowers(user.id);
      res.json(followers);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  app.get("/api/users/:username/following", async (req, res) => {
    try {
      // Special handling for routes like /explore and /settings
      if (req.params.username === 'explore' || req.params.username === 'settings') {
        if (req.isAuthenticated()) {
          const following = await storage.getFollowing(req.user!.id);
          return res.json(following);
        } else {
          return res.status(401).json({ message: "Unauthorized" });
        }
      }
      
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const following = await storage.getFollowing(user.id);
      res.json(following);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  app.get("/api/users/:username/is-following", isAuthenticated, async (req, res) => {
    try {
      // Special handling for routes like /explore and /settings
      if (req.params.username === 'explore' || req.params.username === 'settings') {
        // Since we can't follow ourselves, always return false for these special routes
        return res.json({ following: false });
      }
      
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const isFollowing = await storage.isFollowing(req.user!.id, user.id);
      res.json({ following: isFollowing });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/repositories", isAuthenticated, async (req, res) => {
    try {
      const validData = insertRepositorySchema.parse({
        ...req.body,
        userId: req.user!.id,
      });
      
      const existingRepo = await storage.getRepositoryByUserAndName(req.user!.id, validData.name);
      if (existingRepo) {
        return res.status(400).json({ message: "Repository with this name already exists" });
      }
      
      const repository = await storage.createRepository(validData);
      res.status(201).json(repository);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/repositories/:id", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.id));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      res.json(repository);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.patch("/api/repositories/:id", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.id));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to update this repository" });
      }
      
      const validData = z.object({
        name: z.string().optional(),
        description: z.string().optional(),
        isPrivate: z.boolean().optional(),
      }).parse(req.body);
      
      const updatedRepository = await storage.updateRepository(parseInt(req.params.id), validData);
      res.json(updatedRepository);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.delete("/api/repositories/:id", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.id));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to delete this repository" });
      }
      
      await storage.deleteRepository(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Repository stars
  app.get("/api/repositories/:id/stars", async (req, res) => {
    try {
      const count = await storage.getStarCount(parseInt(req.params.id));
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  app.post("/api/repositories/:id/star", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.id));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const star = await storage.starRepository(req.user!.id, parseInt(req.params.id));
      res.status(201).json(star);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  app.delete("/api/repositories/:id/star", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.id));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      await storage.unstarRepository(req.user!.id, parseInt(req.params.id));
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  // Repository download as ZIP
  app.get("/api/repositories/:username/:repoName/download", async (req, res) => {
    try {
      const { username, repoName } = req.params;
      
      // Find user by username
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Find repository
      const repository = await storage.getRepositoryByUserAndName(user.id, repoName);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // Check if repo is private and user is authenticated and is the owner
      if (repository.isPrivate) {
        if (!req.isAuthenticated()) {
          return res.status(401).json({ message: "Authentication required to download private repository" });
        }
        
        if (repository.userId !== req.user!.id) {
          return res.status(403).json({ message: "You don't have access to this repository" });
        }
      }
      
      // Get repository files
      const files = await storage.getRepositoryFiles(repository.id);
      
      // Create ZIP
      const AdmZip = require('adm-zip');
      const zip = new AdmZip();
      
      // Add files to ZIP
      for (const file of files) {
        zip.addFile(file.path || "unknown.txt", Buffer.from(file.content || ""));
      }
      
      // Set response headers
      res.set('Content-Type', 'application/zip');
      res.set('Content-Disposition', `attachment; filename=${repository.name}.zip`);
      
      // Send ZIP
      res.send(zip.toBuffer());
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  app.get("/api/repositories/:id/starred", isAuthenticated, async (req, res) => {
    try {
      const hasStarred = await storage.hasUserStarredRepository(req.user!.id, parseInt(req.params.id));
      res.json({ starred: hasStarred });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  // Repository forks
  app.get("/api/repositories/:id/forks", async (req, res) => {
    try {
      const count = await storage.getForkCount(parseInt(req.params.id));
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });
  
  // Fork repository
  app.post("/api/repositories/:id/fork", isAuthenticated, async (req, res) => {
    try {
      const sourceRepository = await storage.getRepository(parseInt(req.params.id));
      if (!sourceRepository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (sourceRepository.isPrivate && sourceRepository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      // Create forked repository
      const forkedRepository = await storage.createRepository({
        name: sourceRepository.name,
        description: sourceRepository.description,
        isPrivate: false,
        userId: req.user!.id,
        forkedFromId: sourceRepository.id,
      });
      
      // Copy files from source repository
      const sourceFiles = await storage.getRepositoryFiles(sourceRepository.id);
      
      for (const file of sourceFiles) {
        await storage.createFile({
          repositoryId: forkedRepository.id,
          path: file.path,
          content: file.content,
        });
      }
      
      res.status(201).json(forkedRepository);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // File routes
  app.get("/api/repositories/:repoId/files", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const files = await storage.getRepositoryFiles(parseInt(req.params.repoId));
      res.json(files);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/repositories/:repoId/files/*", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const path = req.params[0];
      const file = await storage.getFileByPath(parseInt(req.params.repoId), path);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      res.json(file);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/repositories/:repoId/files", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to add files to this repository" });
      }
      
      const validData = insertFileSchema.parse({
        ...req.body,
        repositoryId: parseInt(req.params.repoId),
      });
      
      const existingFile = await storage.getFileByPath(parseInt(req.params.repoId), validData.path);
      if (existingFile) {
        return res.status(400).json({ message: "File with this path already exists" });
      }
      
      const file = await storage.createFile(validData);
      
      // Create commit for the file creation
      if (req.body.commitMessage) {
        await storage.createCommit({
          repositoryId: parseInt(req.params.repoId),
          userId: req.user!.id,
          message: req.body.commitMessage,
          changes: { added: [validData.path] },
        });
      }
      
      res.status(201).json(file);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.put("/api/repositories/:repoId/files/*", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to update files in this repository" });
      }
      
      const path = req.params[0];
      const file = await storage.getFileByPath(parseInt(req.params.repoId), path);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      const validData = z.object({
        content: z.string(),
        commitMessage: z.string().optional(),
      }).parse(req.body);
      
      const updatedFile = await storage.updateFile(file.id, { content: validData.content });
      
      // Create commit for the file update
      if (validData.commitMessage) {
        await storage.createCommit({
          repositoryId: parseInt(req.params.repoId),
          userId: req.user!.id,
          message: validData.commitMessage,
          changes: { modified: [path] },
        });
      }
      
      res.json(updatedFile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.delete("/api/repositories/:repoId/files/*", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to delete files from this repository" });
      }
      
      const path = req.params[0];
      const file = await storage.getFileByPath(parseInt(req.params.repoId), path);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }
      
      await storage.deleteFile(file.id);
      
      // Create commit for the file deletion
      if (req.body.commitMessage) {
        await storage.createCommit({
          repositoryId: parseInt(req.params.repoId),
          userId: req.user!.id,
          message: req.body.commitMessage,
          changes: { deleted: [path] },
        });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Commit routes
  app.get("/api/repositories/:repoId/commits", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const commits = await storage.getRepositoryCommits(parseInt(req.params.repoId));
      res.json(commits);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/repositories/:repoId/commits", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      if (repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to commit to this repository" });
      }
      
      const validData = insertCommitSchema.parse({
        ...req.body,
        repositoryId: parseInt(req.params.repoId),
        userId: req.user!.id,
      });
      
      const commit = await storage.createCommit(validData);
      res.status(201).json(commit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Issue routes
  app.get("/api/repositories/:repoId/issues", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const issues = await storage.getRepositoryIssues(parseInt(req.params.repoId));
      res.json(issues);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/repositories/:repoId/issues", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // Users can create issues on any public repository
      if (repository.isPrivate && repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const validData = insertIssueSchema.parse({
        ...req.body,
        repositoryId: parseInt(req.params.repoId),
        userId: req.user!.id,
      });
      
      const issue = await storage.createIssue(validData);
      res.status(201).json(issue);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.patch("/api/issues/:id", isAuthenticated, async (req, res) => {
    try {
      const issue = await storage.getIssue(parseInt(req.params.id));
      if (!issue) {
        return res.status(404).json({ message: "Issue not found" });
      }
      
      const repository = await storage.getRepository(issue.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // Only repository owner or issue creator can update the issue
      if (repository.userId !== req.user!.id && issue.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to update this issue" });
      }
      
      const validData = z.object({
        title: z.string().optional(),
        body: z.string().optional(),
        status: z.enum(["open", "closed"]).optional(),
      }).parse(req.body);
      
      const updatedIssue = await storage.updateIssue(parseInt(req.params.id), validData);
      res.json(updatedIssue);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/issues/:id/comments", async (req, res) => {
    try {
      const issue = await storage.getIssue(parseInt(req.params.id));
      if (!issue) {
        return res.status(404).json({ message: "Issue not found" });
      }
      
      const repository = await storage.getRepository(issue.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const comments = await storage.getIssueComments(parseInt(req.params.id));
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/issues/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const issue = await storage.getIssue(parseInt(req.params.id));
      if (!issue) {
        return res.status(404).json({ message: "Issue not found" });
      }
      
      const repository = await storage.getRepository(issue.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const validData = insertCommentSchema.parse({
        userId: req.user!.id,
        issueId: parseInt(req.params.id),
        content: req.body.content,
      });
      
      const comment = await storage.createComment(validData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Pull request routes
  app.get("/api/repositories/:repoId/pull-requests", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const pullRequests = await storage.getRepositoryPullRequests(parseInt(req.params.repoId));
      res.json(pullRequests);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/repositories/:repoId/pull-requests", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      const validData = insertPullRequestSchema.parse({
        ...req.body,
        repositoryId: parseInt(req.params.repoId),
        userId: req.user!.id,
      });
      
      const pullRequest = await storage.createPullRequest(validData);
      res.status(201).json(pullRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.patch("/api/pull-requests/:id", isAuthenticated, async (req, res) => {
    try {
      const pullRequest = await storage.getPullRequest(parseInt(req.params.id));
      if (!pullRequest) {
        return res.status(404).json({ message: "Pull request not found" });
      }
      
      const repository = await storage.getRepository(pullRequest.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // Only repository owner or PR creator can update the PR
      if (repository.userId !== req.user!.id && pullRequest.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to update this pull request" });
      }
      
      const validData = z.object({
        title: z.string().optional(),
        body: z.string().optional(),
        status: z.enum(["open", "closed", "merged"]).optional(),
      }).parse(req.body);
      
      const updatedPullRequest = await storage.updatePullRequest(parseInt(req.params.id), validData);
      res.json(updatedPullRequest);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/pull-requests/:id/comments", async (req, res) => {
    try {
      const pullRequest = await storage.getPullRequest(parseInt(req.params.id));
      if (!pullRequest) {
        return res.status(404).json({ message: "Pull request not found" });
      }
      
      const repository = await storage.getRepository(pullRequest.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && (!req.isAuthenticated() || repository.userId !== req.user!.id)) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const comments = await storage.getPullRequestComments(parseInt(req.params.id));
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.post("/api/pull-requests/:id/comments", isAuthenticated, async (req, res) => {
    try {
      const pullRequest = await storage.getPullRequest(parseInt(req.params.id));
      if (!pullRequest) {
        return res.status(404).json({ message: "Pull request not found" });
      }
      
      const repository = await storage.getRepository(pullRequest.repositoryId);
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const validData = insertCommentSchema.parse({
        userId: req.user!.id,
        pullRequestId: parseInt(req.params.id),
        content: req.body.content,
      });
      
      const comment = await storage.createComment(validData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Star routes
  app.post("/api/repositories/:repoId/star", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      // If repository is private, check if user is the owner
      if (repository.isPrivate && repository.userId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have access to this repository" });
      }
      
      const hasStarred = await storage.hasUserStarredRepository(req.user!.id, parseInt(req.params.repoId));
      if (hasStarred) {
        return res.status(400).json({ message: "You have already starred this repository" });
      }
      
      const star = await storage.starRepository(req.user!.id, parseInt(req.params.repoId));
      res.status(201).json(star);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.delete("/api/repositories/:repoId/star", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      const result = await storage.unstarRepository(req.user!.id, parseInt(req.params.repoId));
      if (!result) {
        return res.status(404).json({ message: "You have not starred this repository" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/repositories/:repoId/stars", async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      const starCount = await storage.getStarCount(parseInt(req.params.repoId));
      res.json({ count: starCount });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/repositories/:repoId/starred", isAuthenticated, async (req, res) => {
    try {
      const repository = await storage.getRepository(parseInt(req.params.repoId));
      if (!repository) {
        return res.status(404).json({ message: "Repository not found" });
      }
      
      const hasStarred = await storage.hasUserStarredRepository(req.user!.id, parseInt(req.params.repoId));
      res.json({ starred: hasStarred });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/users/:username/starred", async (req, res) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const starredRepositories = await storage.getUserStarredRepositories(user.id);
      res.json(starredRepositories);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  // Follower routes
  app.post("/api/users/:username/follow", isAuthenticated, async (req, res) => {
    try {
      const userToFollow = await storage.getUserByUsername(req.params.username);
      if (!userToFollow) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (userToFollow.id === req.user!.id) {
        return res.status(400).json({ message: "You cannot follow yourself" });
      }
      
      const isAlreadyFollowing = await storage.isFollowing(req.user!.id, userToFollow.id);
      if (isAlreadyFollowing) {
        return res.status(400).json({ message: "You are already following this user" });
      }
      
      const follow = await storage.followUser(req.user!.id, userToFollow.id);
      res.status(201).json(follow);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.delete("/api/users/:username/follow", isAuthenticated, async (req, res) => {
    try {
      const userToUnfollow = await storage.getUserByUsername(req.params.username);
      if (!userToUnfollow) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const result = await storage.unfollowUser(req.user!.id, userToUnfollow.id);
      if (!result) {
        return res.status(404).json({ message: "You are not following this user" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/users/:username/following", async (req, res) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const following = await storage.getFollowing(user.id);
      
      // Don't return passwords
      const followingWithoutPasswords = following.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(followingWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/users/:username/followers", async (req, res) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const followers = await storage.getFollowers(user.id);
      
      // Don't return passwords
      const followersWithoutPasswords = followers.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.json(followersWithoutPasswords);
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  app.get("/api/users/:username/is-following", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const isFollowing = await storage.isFollowing(req.user!.id, user.id);
      res.json({ following: isFollowing });
    } catch (error) {
      res.status(500).json({ message: "Server error", error: (error as Error).message });
    }
  });

  return httpServer;
}
