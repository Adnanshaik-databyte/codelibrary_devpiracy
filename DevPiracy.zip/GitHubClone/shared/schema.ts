import { pgTable, text, serial, integer, boolean, timestamp, json, primaryKey, foreignKey } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  bio: text("bio"),
  location: text("location"),
  website: text("website"),
  avatarUrl: text("avatar_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Repository table
export const repositories = pgTable("repositories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  isPrivate: boolean("is_private").default(false).notNull(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  forkedFromId: integer("forked_from_id").references(() => repositories.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// File table
export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  repositoryId: integer("repository_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  path: text("path").notNull(),
  content: text("content"),
  lastCommitId: integer("last_commit_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Commit table
export const commits = pgTable("commits", {
  id: serial("id").primaryKey(),
  repositoryId: integer("repository_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  message: text("message").notNull(),
  changes: json("changes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Issue table
export const issues = pgTable("issues", {
  id: serial("id").primaryKey(),
  repositoryId: integer("repository_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  body: text("body"),
  status: text("status").notNull().default("open"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Pull request table
export const pullRequests = pgTable("pull_requests", {
  id: serial("id").primaryKey(),
  repositoryId: integer("repository_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  body: text("body"),
  status: text("status").notNull().default("open"),
  sourceBranch: text("source_branch").notNull(),
  targetBranch: text("target_branch").notNull().default("main"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Comments table (for issues and PRs)
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  issueId: integer("issue_id").references(() => issues.id, { onDelete: "cascade" }),
  pullRequestId: integer("pull_request_id").references(() => pullRequests.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Stars table
export const stars = pgTable("stars", {
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  repositoryId: integer("repository_id").notNull().references(() => repositories.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t) => ({
  pk: primaryKey({ columns: [t.userId, t.repositoryId] })
}));

// Followers table
export const followers = pgTable("followers", {
  followerId: integer("follower_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  followingId: integer("following_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (t) => ({
  pk: primaryKey({ columns: [t.followerId, t.followingId] })
}));

// Insert schemas for Zod validation
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  bio: true,
  location: true,
  website: true,
  avatarUrl: true,
});

export const insertRepositorySchema = createInsertSchema(repositories).pick({
  name: true,
  description: true,
  isPrivate: true,
  userId: true,
  forkedFromId: true,
});

export const insertFileSchema = createInsertSchema(files).pick({
  repositoryId: true,
  path: true,
  content: true,
  lastCommitId: true,
});

export const insertCommitSchema = createInsertSchema(commits).pick({
  repositoryId: true,
  userId: true,
  message: true,
  changes: true,
});

export const insertIssueSchema = createInsertSchema(issues).pick({
  repositoryId: true,
  userId: true,
  title: true,
  body: true,
  status: true,
});

export const insertPullRequestSchema = createInsertSchema(pullRequests).pick({
  repositoryId: true,
  userId: true,
  title: true,
  body: true,
  status: true,
  sourceBranch: true,
  targetBranch: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  userId: true,
  content: true,
  issueId: true,
  pullRequestId: true,
});

export const insertStarSchema = createInsertSchema(stars).pick({
  userId: true,
  repositoryId: true,
});

export const insertFollowerSchema = createInsertSchema(followers).pick({
  followerId: true,
  followingId: true,
});

// Export types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Repository = typeof repositories.$inferSelect;
export type InsertRepository = z.infer<typeof insertRepositorySchema>;

export type File = typeof files.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;

export type Commit = typeof commits.$inferSelect;
export type InsertCommit = z.infer<typeof insertCommitSchema>;

export type Issue = typeof issues.$inferSelect;
export type InsertIssue = z.infer<typeof insertIssueSchema>;

export type PullRequest = typeof pullRequests.$inferSelect;
export type InsertPullRequest = z.infer<typeof insertPullRequestSchema>;

export type Comment = typeof comments.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;

export type Star = typeof stars.$inferSelect;
export type InsertStar = z.infer<typeof insertStarSchema>;

export type Follower = typeof followers.$inferSelect;
export type InsertFollower = z.infer<typeof insertFollowerSchema>;
