import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { AuthProvider } from "@/hooks/use-auth";
import { ThemeProvider } from "next-themes";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import { ProtectedRoute } from "./lib/protected-route";
import ProfilePage from "@/pages/profile-page";
import RepositoryPage from "@/pages/repository-page";
import RepositoryCodePage from "@/pages/repository-code-page";
import RepositoryIssuesPage from "@/pages/repository-issues-page";
import CreateRepositoryPage from "@/pages/create-repository-page";
import Header from "@/components/layout/Header";

function Router() {
  return (
    <>
      <Header />
      <Switch>
        <ProtectedRoute path="/" component={HomePage} />
        <Route path="/auth" component={AuthPage} />
        <ProtectedRoute path="/new" component={CreateRepositoryPage} />
        <Route path="/:username" component={ProfilePage} />
        <Route path="/:username/:repoName" component={RepositoryPage} />
        <Route path="/:username/:repoName/code/:path*" component={RepositoryCodePage} />
        <Route path="/:username/:repoName/issues" component={RepositoryIssuesPage} />
        <Route component={NotFound} />
      </Switch>
    </>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class">
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
