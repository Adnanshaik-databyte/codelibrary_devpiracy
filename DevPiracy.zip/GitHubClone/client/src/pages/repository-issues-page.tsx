import { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, AlertCircle, Check, Search } from 'lucide-react';
import { Repository, Issue } from '@shared/schema';

const RepositoryIssuesPage = () => {
  const [match, params] = useRoute('/:username/:repoName/issues');
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [issueTitle, setIssueTitle] = useState('');
  const [issueBody, setIssueBody] = useState('');
  const [issueFilter, setIssueFilter] = useState('open');
  
  // Fetch repository data
  const { data: repository, isLoading: isLoadingRepo } = useQuery<Repository>({
    queryKey: [`/api/users/${params?.username}/repositories/${params?.repoName}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`/api/repositories?username=${params?.username}&name=${params?.repoName}`);
      if (!res.ok) throw new Error('Failed to fetch repository');
      const repos = await res.json();
      return repos.find((repo: Repository) => repo.name === params?.repoName);
    },
    enabled: !!params?.username && !!params?.repoName
  });

  // Fetch issues
  const { 
    data: issues, 
    isLoading: isLoadingIssues 
  } = useQuery<Issue[]>({
    queryKey: [`/api/repositories/${repository?.id}/issues`],
    enabled: !!repository?.id
  });
  
  // Create issue mutation
  const createIssueMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/repositories/${repository?.id}/issues`, {
        title: issueTitle,
        body: issueBody,
      });
    },
    onSuccess: () => {
      setIsCreateDialogOpen(false);
      setIssueTitle('');
      setIssueBody('');
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/issues`] });
      toast({
        title: "Success",
        description: "Issue created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create issue: ${(error as Error).message}`,
        variant: "destructive",
      });
    }
  });

  // Close issue mutation
  const closeIssueMutation = useMutation({
    mutationFn: async (issueId: number) => {
      await apiRequest('PATCH', `/api/issues/${issueId}`, {
        status: 'closed'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/issues`] });
      toast({
        title: "Success",
        description: "Issue closed successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to close issue: ${(error as Error).message}`,
        variant: "destructive",
      });
    }
  });

  // Reopen issue mutation
  const reopenIssueMutation = useMutation({
    mutationFn: async (issueId: number) => {
      await apiRequest('PATCH', `/api/issues/${issueId}`, {
        status: 'open'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/issues`] });
      toast({
        title: "Success",
        description: "Issue reopened successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to reopen issue: ${(error as Error).message}`,
        variant: "destructive",
      });
    }
  });

  const handleCreateIssue = () => {
    if (!issueTitle.trim()) {
      toast({
        title: "Validation Error",
        description: "Issue title is required",
        variant: "destructive",
      });
      return;
    }
    createIssueMutation.mutate();
  };

  const handleCloseIssue = (issueId: number) => {
    closeIssueMutation.mutate(issueId);
  };

  const handleReopenIssue = (issueId: number) => {
    reopenIssueMutation.mutate(issueId);
  };

  const filteredIssues = issues?.filter(issue => 
    issueFilter === 'all' || issue.status === issueFilter
  ) || [];

  if (isLoadingRepo) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-64px)]">
        <Loader2 className="h-10 w-10 animate-spin text-gray-400" />
      </div>
    );
  }

  if (!repository) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Repository not found</h2>
        <p className="text-gray-500 mb-6">
          The repository you're looking for doesn't exist or you don't have permission to view it.
        </p>
        <Link href="/">
          <Button>Go to Home</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-4">
        <div className="flex items-center mb-2">
          <Link href={`/${params?.username}`} className="text-blue-500 hover:underline mr-1">
            {params?.username}
          </Link>
          <span className="mx-1 text-gray-500">/</span>
          <Link href={`/${params?.username}/${params?.repoName}`} className="text-blue-500 hover:underline font-semibold">
            {repository.name}
          </Link>
          <span className="ml-2 text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
            {repository.isPrivate ? 'Private' : 'Public'}
          </span>
        </div>
      </div>

      <div className="border-b border-gray-200 mb-6">
        <div className="flex overflow-x-auto">
          <Link href={`/${params?.username}/${params?.repoName}`} className="px-4 py-2 border-b-2 border-transparent text-gray-500 hover:text-gray-700 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
            </svg>
            Code
          </Link>
          <Link href={`/${params?.username}/${params?.repoName}/issues`} className="px-4 py-2 border-b-2 border-blue-500 font-medium text-blue-500 flex items-center">
            <AlertCircle className="h-4 w-4 mr-2" />
            Issues
          </Link>
          <Link href={`/${params?.username}/${params?.repoName}/pulls`} className="px-4 py-2 border-b-2 border-transparent text-gray-500 hover:text-gray-700 flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
            </svg>
            Pull requests
          </Link>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
          <div className="flex items-center w-full md:w-auto mb-4 md:mb-0">
            <div className="relative flex-grow md:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <Input 
                placeholder="Search issues" 
                className="pl-10"
              />
            </div>
            <div className="ml-4">
              <Tabs defaultValue="open" onValueChange={setIssueFilter}>
                <TabsList>
                  <TabsTrigger value="open">Open</TabsTrigger>
                  <TabsTrigger value="closed">Closed</TabsTrigger>
                  <TabsTrigger value="all">All</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
          
          <Button 
            className="w-full md:w-auto bg-[#2ea44f] hover:bg-[#2c974b]"
            onClick={() => setIsCreateDialogOpen(true)}
            disabled={!user}
          >
            New issue
          </Button>
        </div>

        {isLoadingIssues ? (
          <div className="flex justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
          </div>
        ) : filteredIssues.length === 0 ? (
          <div className="border border-gray-200 rounded-md p-8 text-center">
            <AlertCircle className="h-16 w-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium mb-2">No matching issues found</h3>
            <p className="text-gray-500 mb-4">
              {issueFilter === 'open' 
                ? "There are no open issues yet." 
                : issueFilter === 'closed' 
                  ? "There are no closed issues yet."
                  : "There are no issues yet."}
            </p>
            <Button 
              className="bg-[#2ea44f] hover:bg-[#2c974b]"
              onClick={() => setIsCreateDialogOpen(true)}
              disabled={!user}
            >
              Create issue
            </Button>
          </div>
        ) : (
          <div className="border border-gray-200 rounded-md divide-y divide-gray-200">
            {filteredIssues.map((issue) => (
              <div key={issue.id} className="p-4 hover:bg-gray-50">
                <div className="flex items-start">
                  <div className="mr-3 mt-1">
                    {issue.status === 'open' ? (
                      <AlertCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <Check className="h-5 w-5 text-purple-500" />
                    )}
                  </div>
                  <div className="flex-grow">
                    <div className="mb-1">
                      <Link href={`/${params?.username}/${params?.repoName}/issues/${issue.id}`} className="font-medium text-blue-500 hover:underline">
                        {issue.title}
                      </Link>
                    </div>
                    <div className="text-sm text-gray-500">
                      #{issue.id} opened {new Date(issue.createdAt).toLocaleDateString()} by {params?.username}
                    </div>
                  </div>
                  <div className="ml-4">
                    {user && (
                      issue.status === 'open' ? (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleCloseIssue(issue.id)} 
                          disabled={closeIssueMutation.isPending}
                        >
                          Close
                        </Button>
                      ) : (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleReopenIssue(issue.id)}
                          disabled={reopenIssueMutation.isPending}
                        >
                          Reopen
                        </Button>
                      )
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Create a new issue</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title
              </label>
              <Input
                id="title"
                placeholder="Issue title"
                value={issueTitle}
                onChange={(e) => setIssueTitle(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="body" className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <Textarea
                id="body"
                placeholder="Add a description..."
                value={issueBody}
                onChange={(e) => setIssueBody(e.target.value)}
                rows={5}
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsCreateDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="bg-[#2ea44f] hover:bg-[#2c974b]"
              onClick={handleCreateIssue}
              disabled={createIssueMutation.isPending || !issueTitle.trim()}
            >
              {createIssueMutation.isPending ? "Creating..." : "Create issue"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RepositoryIssuesPage;
