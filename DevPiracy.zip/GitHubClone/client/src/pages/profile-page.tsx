import { useState, useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2 } from 'lucide-react';
import Sidebar from '@/components/layout/Sidebar';
import RepositoryCard from '@/components/home/RepositoryCard';
import { useToast } from '@/hooks/use-toast';
import type { User, Repository } from '@shared/schema';

export default function ProfilePage() {
  const [match, params] = useRoute('/:username');
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('overview');

  // Get query params
  const url = new URL(window.location.href);
  const queryTab = url.searchParams.get('tab');

  useEffect(() => {
    if (queryTab) {
      setActiveTab(queryTab);
    }
  }, [queryTab]);

  // Get profile user data
  const {
    data: profileUser,
    isLoading: isLoadingUser,
    error: userError
  } = useQuery<Omit<User, 'password'>>({
    queryKey: [`/api/users/${params?.username}`],
    enabled: !!params?.username
  });

  // Get user's repositories
  const {
    data: repositories,
    isLoading: isLoadingRepos
  } = useQuery<Repository[]>({
    queryKey: [`/api/users/${params?.username}/repositories`],
    enabled: !!params?.username
  });

  // Get starred repositories
  const {
    data: starredRepos,
    isLoading: isLoadingStarred
  } = useQuery<Repository[]>({
    queryKey: [`/api/users/${params?.username}/starred`],
    enabled: !!params?.username && activeTab === 'stars'
  });

  // Get follower and following counts
  const { data: followers } = useQuery<User[]>({
    queryKey: [`/api/users/${params?.username}/followers`],
    enabled: !!params?.username
  });

  const { data: following } = useQuery<User[]>({
    queryKey: [`/api/users/${params?.username}/following`],
    enabled: !!params?.username
  });

  // Check if current user is following this profile
  const { data: followStatus } = useQuery<{ following: boolean }>({
    queryKey: [`/api/users/${params?.username}/is-following`],
    enabled: !!params?.username && !!user && params?.username !== user.username
  });

  // Follow user mutation
  const followMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/users/${params?.username}/follow`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${params?.username}/is-following`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${params?.username}/followers`] });
      toast({
        title: "Success",
        description: `You are now following ${params?.username}`,
      });
    }
  });

  // Unfollow user mutation
  const unfollowMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/users/${params?.username}/follow`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${params?.username}/is-following`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${params?.username}/followers`] });
      toast({
        title: "Success",
        description: `You have unfollowed ${params?.username}`,
      });
    }
  });

  const isCurrentUser = user && profileUser && user.id === profileUser.id;
  const isFollowing = followStatus?.following || false;

  const handleFollow = () => {
    followMutation.mutate();
  };

  const handleUnfollow = () => {
    unfollowMutation.mutate();
  };

  // Loading state
  if (isLoadingUser) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-64px)]">
        <Loader2 className="h-10 w-10 animate-spin text-gray-400" />
      </div>
    );
  }

  // Error state
  if (userError || !profileUser) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">User not found</h2>
        <p className="text-gray-500 mb-6">
          The user you're looking for doesn't exist or you don't have permission to view their profile.
        </p>
        <button 
          onClick={() => navigate('/')}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md"
        >
          Go to Home
        </button>
      </div>
    );
  }

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col md:flex-row">
        {/* Left sidebar */}
        <Sidebar 
          profileUser={profileUser}
          followers={followers?.length || 0}
          following={following?.length || 0}
          isCurrentUser={isCurrentUser}
          isFollowing={isFollowing}
          onFollow={handleFollow}
          onUnfollow={handleUnfollow}
        />

        {/* Main content area */}
        <div className="w-full md:w-3/4">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="border-b border-gray-200 mb-6">
              <TabsList className="flex overflow-x-auto">
                <TabsTrigger value="overview" className="px-4 py-2">
                  Overview
                </TabsTrigger>
                <TabsTrigger value="repositories" className="px-4 py-2">
                  Repositories {repositories && <span className="ml-1 bg-gray-200 text-gray-600 rounded-full px-2 py-0.5 text-xs">{repositories.length}</span>}
                </TabsTrigger>
                <TabsTrigger value="stars" className="px-4 py-2">
                  Stars {starredRepos && <span className="ml-1 bg-gray-200 text-gray-600 rounded-full px-2 py-0.5 text-xs">{starredRepos.length}</span>}
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="overview" className="mt-0">
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium">Popular repositories</h2>
                  {repositories && repositories.length > 0 && (
                    <button 
                      onClick={() => setActiveTab('repositories')}
                      className="text-sm text-blue-500 hover:underline"
                    >
                      View all
                    </button>
                  )}
                </div>

                {isLoadingRepos ? (
                  <div className="flex justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : repositories?.length === 0 ? (
                  <div className="border border-gray-200 rounded-md p-8 text-center">
                    <h3 className="text-lg font-medium mb-2">{isCurrentUser ? "You don't" : `${profileUser.username} doesn't`} have any public repositories yet.</h3>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {repositories.slice(0, 4).map((repo) => (
                      <RepositoryCard key={repo.id} repository={repo} />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="repositories" className="mt-0">
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium">Repositories</h2>
                </div>

                {isLoadingRepos ? (
                  <div className="flex justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : repositories?.length === 0 ? (
                  <div className="border border-gray-200 rounded-md p-8 text-center">
                    <h3 className="text-lg font-medium mb-2">{isCurrentUser ? "You don't" : `${profileUser.username} doesn't`} have any public repositories yet.</h3>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {repositories.map((repo) => (
                      <div key={repo.id} className="border border-gray-200 rounded-md p-4">
                        <div className="flex flex-col">
                          <div className="flex items-center mb-2">
                            <a href={`/${profileUser.username}/${repo.name}`} className="text-blue-500 font-medium hover:underline">{repo.name}</a>
                            <span className="ml-2 text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
                              {repo.isPrivate ? 'Private' : 'Public'}
                            </span>
                          </div>
                          <p className="text-gray-600 text-sm mb-3">{repo.description || 'No description provided'}</p>
                          <div className="flex items-center text-xs text-gray-500">
                            <span className="mr-3">Updated {new Date(repo.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="stars" className="mt-0">
              <div className="mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-lg font-medium">Starred repositories</h2>
                </div>

                {isLoadingStarred ? (
                  <div className="flex justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : !starredRepos || starredRepos.length === 0 ? (
                  <div className="border border-gray-200 rounded-md p-8 text-center">
                    <h3 className="text-lg font-medium mb-2">{isCurrentUser ? "You haven't" : `${profileUser.username} hasn't`} starred any repositories yet.</h3>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 gap-4">
                    {starredRepos.map((repo) => (
                      <div key={repo.id} className="border border-gray-200 rounded-md p-4">
                        <div className="flex flex-col">
                          <div className="flex items-center mb-2">
                            <a href={`/${profileUser.username}/${repo.name}`} className="text-blue-500 font-medium hover:underline">{repo.name}</a>
                            <span className="ml-2 text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
                              {repo.isPrivate ? 'Private' : 'Public'}
                            </span>
                          </div>
                          <p className="text-gray-600 text-sm mb-3">{repo.description || 'No description provided'}</p>
                          <div className="flex items-center text-xs text-gray-500">
                            <span className="mr-3">Updated {new Date(repo.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  );
}
