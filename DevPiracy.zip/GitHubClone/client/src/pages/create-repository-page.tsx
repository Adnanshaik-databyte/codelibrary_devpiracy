import { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { BookOpenCheck, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Repository } from '@shared/schema';

const CreateRepositoryPage = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [_, navigate] = useLocation();

  const [repoName, setRepoName] = useState('');
  const [description, setDescription] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);
  const [nameError, setNameError] = useState('');

  // Regex for valid repository names
  const validNameRegex = /^[a-zA-Z0-9._-]+$/;

  // Create repository mutation
  const createRepoMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/repositories', {
        name: repoName,
        description,
        isPrivate,
      });
      return response.json() as Promise<Repository>;
    },
    onSuccess: (data) => {
      toast({
        title: "Repository created",
        description: `${repoName} has been created successfully.`,
      });
      navigate(`/${user?.username}/${data.name}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create repository: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setRepoName(value);
    
    if (!value) {
      setNameError('Repository name is required');
    } else if (!validNameRegex.test(value)) {
      setNameError('Repository name can only contain letters, numbers, hyphens, periods, and underscores');
    } else if (value.length > 100) {
      setNameError('Repository name must be less than 100 characters');
    } else {
      setNameError('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!repoName) {
      setNameError('Repository name is required');
      return;
    }
    
    if (nameError) return;
    
    createRepoMutation.mutate();
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <h1 className="text-3xl font-bold mb-6">Create a new repository</h1>
      <Card>
        <CardHeader>
          <CardTitle>Repository details</CardTitle>
          <CardDescription>Fill in the information for your new repository</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="owner" className="text-sm font-medium">Owner</Label>
              <div className="flex items-center px-3 py-2 bg-gray-100 rounded-md">
                <span className="text-gray-700">{user?.username}</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name" className="text-sm font-medium">
                Repository name <span className="text-red-500">*</span>
              </Label>
              <Input
                id="name"
                value={repoName}
                onChange={handleNameChange}
                placeholder="my-awesome-project"
                className={nameError ? "border-red-500" : ""}
              />
              {nameError && <p className="text-sm text-red-500">{nameError}</p>}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description" className="text-sm font-medium">Description (optional)</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="A short description of your repository"
                rows={3}
              />
            </div>
            
            <div className="space-y-4 pt-4">
              <div className="flex items-start space-x-4">
                <div className="mt-0.5">
                  {isPrivate ? (
                    <Lock className="h-9 w-9 text-gray-500 p-1.5 bg-gray-100 rounded-full" />
                  ) : (
                    <BookOpenCheck className="h-9 w-9 text-gray-500 p-1.5 bg-gray-100 rounded-full" />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-medium">{isPrivate ? "Private" : "Public"}</h3>
                      <p className="text-sm text-gray-500">
                        {isPrivate 
                          ? "You choose who can see and commit to this repository." 
                          : "Anyone on the internet can see this repository."}
                      </p>
                    </div>
                    <Switch 
                      checked={isPrivate} 
                      onCheckedChange={setIsPrivate}
                      id="privacy-toggle"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="pt-4">
              <Button 
                type="submit" 
                className="w-full md:w-auto bg-[#2ea44f] hover:bg-[#2c974b]"
                disabled={createRepoMutation.isPending || !!nameError}
              >
                {createRepoMutation.isPending ? "Creating repository..." : "Create repository"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default CreateRepositoryPage;
