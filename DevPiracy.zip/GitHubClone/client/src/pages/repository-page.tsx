import { useState } from 'react';
import { useRoute, Link } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import {
  Loader2, Star, GitFork, EyeOff, AlertOctagon, GitPullRequest, Play,
  Compass, BookOpen, Shield, BarChart3, Download, Plus, Upload, FileText
} from 'lucide-react';
import { Repository, File } from '@shared/schema';
import FileExplorer from '@/components/repository/FileExplorer';
import Commit from '@/components/repository/Commit';
import FileForm from '@/components/repository/FileForm';
import FileUpload from '@/components/repository/FileUpload';

const RepositoryPage = () => {
  const [match, params] = useRoute('/:username/:repoName');
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('code');
  const [fileFormOpen, setFileFormOpen] = useState(false);
  const [fileUploadOpen, setFileUploadOpen] = useState(false);

  // Fetch repository data
  const { data: repository, isLoading: isLoadingRepo } = useQuery<Repository>({
    queryKey: [`/api/users/${params?.username}/repositories/${params?.repoName}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`/api/repositories?username=${params?.username}&name=${params?.repoName}`);
      if (!res.ok) throw new Error('Failed to fetch repository');
      const repos = await res.json();
      return repos.find((repo: Repository) => repo.name === params?.repoName);
    },
    enabled: !!params?.username && !!params?.repoName
  });

  // Fetch repository files
  const { data: files, isLoading: isLoadingFiles } = useQuery<File[]>({
    queryKey: [`/api/repositories/${repository?.id}/files`],
    enabled: !!repository?.id
  });

  // Fetch commits
  const { data: commits, isLoading: isLoadingCommits } = useQuery<any[]>({
    queryKey: [`/api/repositories/${repository?.id}/commits`],
    enabled: !!repository?.id
  });

  // Check if user has starred the repository
  const { data: starData, isLoading: isLoadingStarStatus } = useQuery<{ starred: boolean }>({
    queryKey: [`/api/repositories/${repository?.id}/starred`],
    enabled: !!repository?.id && !!user
  });

  // Get star count
  const { data: starCountData } = useQuery<{ count: number }>({
    queryKey: [`/api/repositories/${repository?.id}/stars`],
    enabled: !!repository?.id
  });

  // Star repository mutation
  const starMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/repositories/${repository?.id}/star`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/starred`] });
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/stars`] });
      toast({
        title: "Success",
        description: `You have starred ${params?.username}/${params?.repoName}`,
      });
    }
  });

  // Unstar repository mutation
  const unstarMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', `/api/repositories/${repository?.id}/star`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/starred`] });
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository?.id}/stars`] });
      toast({
        title: "Success",
        description: `You have unstarred ${params?.username}/${params?.repoName}`,
      });
    }
  });

  const handleStarToggle = () => {
    if (starData?.starred) {
      unstarMutation.mutate();
    } else {
      starMutation.mutate();
    }
  };

  if (isLoadingRepo) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-64px)]">
        <Loader2 className="h-10 w-10 animate-spin text-gray-400" />
      </div>
    );
  }

  if (!repository) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Repository not found</h2>
        <p className="text-gray-500 mb-6">
          The repository you're looking for doesn't exist or you don't have permission to view it.
        </p>
        <Link href="/">
          <Button>Go to Home</Button>
        </Link>
      </div>
    );
  }

  const isOwner = user && repository.userId === user.id;

  return (
    <div className="container mx-auto px-4 py-6">
      {/* File creation and upload forms */}
      <FileForm 
        open={fileFormOpen} 
        onOpenChange={setFileFormOpen} 
        repositoryId={repository.id} 
        username={params?.username || ''} 
        repoName={repository.name}
      />
      <FileUpload 
        open={fileUploadOpen} 
        onOpenChange={setFileUploadOpen} 
        repositoryId={repository.id} 
        username={params?.username || ''} 
        repoName={repository.name}
      />
      
      <div className="mb-4">
        <div className="flex items-center mb-2">
          <BookOpen className="text-gray-500 mr-2" size={16} />
          <Link href={`/${params?.username}`} className="text-blue-500 hover:underline mr-1">
            {params?.username}
          </Link>
          <span className="mx-1 text-gray-500">/</span>
          <Link href={`/${params?.username}/${params?.repoName}`} className="text-blue-500 hover:underline font-semibold">
            {repository.name}
          </Link>
          <span className="ml-2 text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
            {repository.isPrivate ? 'Private' : 'Public'}
          </span>
        </div>
        
        <p className="text-gray-500 mb-4">{repository.description || 'No description provided'}</p>
        
        <div className="flex flex-wrap mb-4">
          <Button 
            variant="outline" 
            size="sm" 
            className="mr-2 mb-2"
            onClick={handleStarToggle}
            disabled={!user || starMutation.isPending || unstarMutation.isPending}
          >
            <Star className={`mr-1 ${starData?.starred ? 'fill-current' : ''}`} size={16} /> 
            {starData?.starred ? 'Unstar' : 'Star'} 
            {starCountData && <span className="ml-1">{starCountData.count}</span>}
          </Button>
          
          {!isOwner && (
            <Button 
              variant="outline" 
              size="sm" 
              className="mr-2 mb-2"
              onClick={() => {
                if (user) {
                  window.location.href = `/api/repositories/${repository.id}/fork`;
                  toast({
                    title: "Forking repository",
                    description: "Please wait while we create your fork...",
                  });
                } else {
                  toast({
                    title: "Authentication required",
                    description: "You need to sign in to fork this repository",
                    variant: "destructive",
                  });
                }
              }}
              disabled={!user}
            >
              <GitFork className="mr-1" size={16} /> Fork
            </Button>
          )}
        </div>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="border-b border-gray-200">
            <TabsList className="flex h-auto p-0 bg-transparent">
              <TabsTrigger 
                value="code" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                  </svg>
                  Code
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="issues" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <AlertOctagon className="h-4 w-4 mr-2" />
                  Issues
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="pull-requests" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <GitPullRequest className="h-4 w-4 mr-2" />
                  Pull requests
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="actions" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <Play className="h-4 w-4 mr-2" />
                  Actions
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="wiki" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Wiki
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="security" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <Shield className="h-4 w-4 mr-2" />
                  Security
                </div>
              </TabsTrigger>
              
              <TabsTrigger 
                value="insights" 
                className="px-4 py-2 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-500 bg-transparent text-gray-500 hover:text-gray-900 rounded-none"
              >
                <div className="flex items-center">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Insights
                </div>
              </TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="code" className="py-4">
            <div className="flex flex-col md:flex-row">
              <div className="w-full md:w-3/4 md:pr-6">
                <div className="mb-4 flex flex-wrap justify-between items-center bg-gray-50 border border-gray-200 rounded-md p-4">
                  <div className="flex items-center mb-2 md:mb-0">
                    <Button variant="ghost" size="sm" className="text-gray-700 mr-3">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zM16 19v-6a2 2 0 01-2-2H6m5 4v6m-1-12a2 2 0 002-2V5a2 2 0 00-2-2h-1a2 2 0 00-2 2v2a2 2 0 002 2h1zm5 0a2 2 0 002-2V5a2 2 0 00-2-2h-1a2 2 0 00-2 2v2a2 2 0 002 2h1z" />
                      </svg>
                      <span className="font-semibold">main</span>
                    </Button>
                  </div>
                  
                  <div className="flex flex-wrap">
                    {/* Download button - available for all users */}
                    <a 
                      href={`/api/repositories/${params?.username}/${repository.name}/download`}
                      download={`${repository.name}.zip`}
                    >
                      <Button variant="outline" size="sm" className="mr-2 mb-2 md:mb-0">
                        <Download className="h-4 w-4 mr-1" />
                        Download ZIP
                      </Button>
                    </a>
                    
                    {isOwner && (
                      <>
                        <Button variant="outline" size="sm" className="mr-2 mb-2 md:mb-0">
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
                          </svg>
                          Clone
                        </Button>
                        <Button variant="default" size="sm" className="mr-2 mb-2 md:mb-0 bg-[#2ea44f] hover:bg-[#2c974b]">
                          <GitPullRequest className="h-4 w-4 mr-1" />
                          Create PR
                        </Button>
                        <div className="dropdown relative">
                          <Button variant="outline" size="sm" className="flex items-center">
                            <Plus className="h-4 w-4 mr-1" />
                            Add file
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                          </Button>
                          <div className="dropdown-menu absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10 hidden hover:block focus:block group-hover:block">
                            <div className="py-1">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="w-full justify-start px-4 rounded-none"
                                onClick={() => setFileFormOpen(true)}
                              >
                                <FileText className="h-4 w-4 mr-2" />
                                Create new file
                              </Button>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="w-full justify-start px-4 rounded-none"
                                onClick={() => setFileUploadOpen(true)}
                              >
                                <Upload className="h-4 w-4 mr-2" />
                                Upload files
                              </Button>
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
                
                {isLoadingFiles ? (
                  <div className="flex justify-center p-8">
                    <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
                  </div>
                ) : !files || files.length === 0 ? (
                  <div className="border border-gray-200 rounded-md p-8 text-center">
                    <h3 className="text-lg font-medium mb-2">This repository is empty</h3>
                    {isOwner && (
                      <p className="text-gray-500 mb-4">
                        Create a new file or upload a file to get started.
                      </p>
                    )}
                  </div>
                ) : (
                  <>
                    {commits && commits.length > 0 && (
                      <div className="border border-gray-200 rounded-md mb-6">
                        <Commit commit={commits[0]} username={params?.username} />
                      </div>
                    )}
                    
                    <div className="border border-gray-200 rounded-md">
                      <FileExplorer 
                        files={files} 
                        repoName={repository.name} 
                        username={params?.username || ''} 
                      />
                    </div>
                  </>
                )}
              </div>
              
              <div className="w-full md:w-1/4 mt-6 md:mt-0">
                <div className="border border-gray-200 rounded-md mb-6">
                  <div className="bg-gray-50 border-b border-gray-200 p-3">
                    <h3 className="font-medium">About</h3>
                  </div>
                  
                  <div className="p-3">
                    <p className="text-sm text-gray-500 mb-3">{repository.description || 'No description provided'}</p>
                    
                    <div className="text-sm mb-3">
                      <div className="flex items-center mb-1">
                        <Star className="h-4 w-4 text-gray-500 mr-2" />
                        <span>{starCountData?.count || 0} stars</span>
                      </div>
                      <div className="flex items-center mb-1">
                        <EyeOff className="h-4 w-4 text-gray-500 mr-2" />
                        <span>1 watching</span>
                      </div>
                      <div className="flex items-center">
                        <GitFork className="h-4 w-4 text-gray-500 mr-2" />
                        <span>0 forks</span>
                      </div>
                    </div>
                  </div>
                </div>
                
                {repository.forkedFromId && (
                  <div className="border border-gray-200 rounded-md mb-6">
                    <div className="bg-gray-50 border-b border-gray-200 p-3">
                      <h3 className="font-medium">Forked from</h3>
                    </div>
                    
                    <div className="p-3">
                      <Link href="/" className="text-blue-500 hover:underline">
                        original/repository
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="issues">
            <div className="py-8 text-center">
              <AlertOctagon className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">No issues yet</h3>
              <p className="text-gray-500 mb-4">Issues are used to track todos, bugs, feature requests, and more.</p>
              {isOwner && (
                <Link href={`/${params?.username}/${params?.repoName}/issues/new`}>
                  <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">Create issue</Button>
                </Link>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="pull-requests">
            <div className="py-8 text-center">
              <GitPullRequest className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">No pull requests yet</h3>
              <p className="text-gray-500 mb-4">Pull requests help you collaborate on code with other people.</p>
              {!isOwner && (
                <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">Create pull request</Button>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="actions">
            <div className="py-8 text-center">
              <Play className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">Get started with GitHub Actions</h3>
              <p className="text-gray-500 mb-4">Automate your workflows with GitHub Actions.</p>
              {isOwner && (
                <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">Set up workflows</Button>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="wiki">
            <div className="py-8 text-center">
              <BookOpen className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">No wiki pages yet</h3>
              <p className="text-gray-500 mb-4">Wikis are great for documenting your project.</p>
              {isOwner && (
                <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">Create wiki</Button>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="security">
            <div className="py-8 text-center">
              <Shield className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">Security overview</h3>
              <p className="text-gray-500 mb-4">View and manage security alerts for this repository.</p>
              {isOwner && (
                <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">Set up security policies</Button>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="insights">
            <div className="py-8 text-center">
              <BarChart3 className="h-16 w-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium mb-2">Repository insights</h3>
              <p className="text-gray-500 mb-4">View detailed statistics for this repository.</p>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default RepositoryPage;
