import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import RepositoryCard from '@/components/home/RepositoryCard';
import ActivityItem from '@/components/home/ActivityItem';
import { Loader2, Plus, Search } from 'lucide-react';
import type { Repository } from '@shared/schema';

export default function HomePage() {
  const { user } = useAuth();
  const [location] = useLocation();
  
  // Parse query parameter
  const searchQuery = new URLSearchParams(location.split('?')[1]).get('q');
  
  // Fetch user's repositories or search results
  const { 
    data: repositories, 
    isLoading: isLoadingRepos,
    error: reposError
  } = useQuery<Repository[]>({
    queryKey: ['/api/repositories', searchQuery], 
    queryFn: async () => {
      if (searchQuery) {
        const response = await fetch(`/api/repositories?q=${encodeURIComponent(searchQuery)}`);
        if (!response.ok) throw new Error('Search failed');
        return response.json();
      } else {
        const response = await fetch('/api/repositories');
        if (!response.ok) throw new Error('Failed to fetch repositories');
        return response.json();
      }
    },
    enabled: !!user
  });

  // Get repositories to display (all for search, or top 4 for homepage)
  const popularRepos = searchQuery ? repositories || [] : (repositories?.slice(0, 4) || []);

  // Define the activity type for type safety
  type ActivityType = {
    id: number;
    type: 'branch' | 'star' | 'repository';
    user: string | undefined;
    repoName: string;
    description: string;
    time: string;
  };

  // For a real app, we'd fetch actual activity, but for now we'll create placeholder data
  const recentActivity: ActivityType[] = [
    {
      id: 1,
      type: 'branch',
      user: user?.username,
      repoName: popularRepos[0]?.name || 'repository',
      description: 'created a branch feature/auth-redesign',
      time: '2 days ago'
    },
    {
      id: 2,
      type: 'star',
      user: user?.username,
      repoName: 'facebook/react',
      description: 'starred facebook/react',
      time: '3 days ago'
    },
    {
      id: 3,
      type: 'repository',
      user: user?.username,
      repoName: popularRepos[1]?.name || 'api-toolkit',
      description: `created repository ${user?.username}/${popularRepos[1]?.name || 'api-toolkit'}`,
      time: '1 week ago'
    }
  ];

  if (!user) return null;

  return (
    <main className="container mx-auto px-4 py-6">
      <div className="flex flex-col md:flex-row">
        {/* Left sidebar - User profile */}
        <div className="w-full md:w-1/4 md:pr-6 mb-6 md:mb-0">
          <div className="mb-6">
            <div className="flex md:block items-center">
              <div 
                className="w-16 h-16 md:w-full md:h-auto md:max-w-[260px] rounded-full md:rounded-md bg-gray-200 flex items-center justify-center text-2xl text-gray-600"
              >
                {user.avatarUrl ? (
                  <img 
                    src={user.avatarUrl} 
                    alt={user.username} 
                    className="w-full h-full object-cover rounded-full md:rounded-md" 
                  />
                ) : (
                  user.username.charAt(0).toUpperCase()
                )}
              </div>
              <div className="ml-4 md:ml-0 md:mt-3">
                <h1 className="text-2xl font-bold">{user.username}</h1>
                <p className="text-gray-500">@{user.username}</p>
              </div>
            </div>
            
            <div className="mt-4">
              <p className="text-gray-600 mb-3">{user.bio || 'Add a bio to your profile'}</p>
              <Link href="/settings">
                <Button variant="outline" className="w-full mb-4">Edit profile</Button>
              </Link>
              
              {user.location && (
                <div className="flex items-center text-sm mb-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="text-gray-600">{user.location}</span>
                </div>
              )}
              
              {user.email && (
                <div className="flex items-center text-sm mb-1">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <a href={`mailto:${user.email}`} className="text-blue-500 hover:underline">{user.email}</a>
                </div>
              )}
              
              {user.website && (
                <div className="flex items-center text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                  </svg>
                  <a href={user.website} className="text-blue-500 hover:underline" target="_blank" rel="noopener noreferrer">{user.website}</a>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Main content area */}
        <div className="w-full md:w-3/4">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-medium">
                {searchQuery 
                  ? `Search results for "${searchQuery}"` 
                  : "Popular repositories"
                }
              </h2>
              {!searchQuery && (
                <Link href={`/${user.username}?tab=repositories`} className="text-sm text-blue-500 hover:underline">
                  See all
                </Link>
              )}
              {searchQuery && (
                <Button variant="ghost" size="sm" onClick={() => window.location.href = '/'}>
                  Clear search
                </Button>
              )}
            </div>

            {isLoadingRepos ? (
              <div className="flex justify-center p-8">
                <Loader2 className="h-8 w-8 animate-spin text-gray-400" />
              </div>
            ) : reposError ? (
              <div className="text-center p-8 text-red-500">
                Failed to load repositories
              </div>
            ) : repositories?.length === 0 ? (
              <div className="border border-gray-200 rounded-md p-8 text-center">
                {searchQuery ? (
                  <>
                    <h3 className="text-lg font-medium mb-2">No results found for "{searchQuery}"</h3>
                    <p className="text-gray-500 mb-4">Try using different keywords or check your spelling</p>
                  </>
                ) : (
                  <>
                    <h3 className="text-lg font-medium mb-2">You don't have any repositories yet</h3>
                    <p className="text-gray-500 mb-4">Repositories are where you store your code and collaborate with others</p>
                    <Link href="/new">
                      <Button className="bg-[#2ea44f] hover:bg-[#2c974b]">
                        <Plus className="mr-2 h-4 w-4" />
                        New repository
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {popularRepos.map((repo) => (
                  <RepositoryCard key={repo.id} repository={repo} />
                ))}
              </div>
            )}
          </div>

          {!searchQuery && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-medium">Recent activity</h2>
              </div>

              <div className="border border-gray-200 rounded-md divide-y divide-gray-200">
                {recentActivity.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    <p>You don't have any recent activity</p>
                  </div>
                ) : (
                  recentActivity.map((activity) => (
                    <ActivityItem key={activity.id} activity={activity} />
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
