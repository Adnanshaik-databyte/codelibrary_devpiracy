import { useState, useEffect } from 'react';
import { useRoute, Link, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import { Loader2, BookOpen, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CodeViewer from '@/components/repository/CodeViewer';
import CodeEditor from '@/components/ui/code-editor';
import { useToast } from '@/hooks/use-toast';
import { apiRequest, queryClient } from '@/lib/queryClient';
import type { Repository, File } from '@shared/schema';

const RepositoryCodePage = () => {
  const [match, params] = useRoute('/:username/:repoName/code/:path*');
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditMode, setIsEditMode] = useState(false);
  const [fileContent, setFileContent] = useState('');
  const [commitMessage, setCommitMessage] = useState('');
  const path = params?.path || '';

  // Fetch repository data
  const { data: repository, isLoading: isLoadingRepo } = useQuery<Repository>({
    queryKey: [`/api/users/${params?.username}/repositories/${params?.repoName}`],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(`/api/repositories?username=${params?.username}&name=${params?.repoName}`);
      if (!res.ok) throw new Error('Failed to fetch repository');
      const repos = await res.json();
      return repos.find((repo: Repository) => repo.name === params?.repoName);
    },
    enabled: !!params?.username && !!params?.repoName
  });

  // Fetch file data
  const { 
    data: file, 
    isLoading: isLoadingFile,
    error: fileError 
  } = useQuery<File>({
    queryKey: [`/api/repositories/${repository?.id}/files/${path}`],
    enabled: !!repository?.id && !!path
  });

  useEffect(() => {
    if (file?.content) {
      setFileContent(file.content);
    }
  }, [file]);

  const handleEditClick = () => {
    setIsEditMode(true);
  };

  const handleCancelEdit = () => {
    setIsEditMode(false);
    setFileContent(file?.content || '');
  };

  const handleSaveChanges = async () => {
    if (!repository || !file || !commitMessage) {
      toast({
        title: "Error",
        description: "Commit message is required",
        variant: "destructive",
      });
      return;
    }

    try {
      await apiRequest(
        'PUT', 
        `/api/repositories/${repository.id}/files/${path}`, 
        { content: fileContent, commitMessage }
      );
      
      toast({
        title: "Success",
        description: "File updated successfully",
      });
      
      setIsEditMode(false);
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository.id}/files/${path}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repository.id}/commits`] });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to update file: ${(error as Error).message}`,
        variant: "destructive",
      });
    }
  };

  if (isLoadingRepo || isLoadingFile) {
    return (
      <div className="flex justify-center items-center min-h-[calc(100vh-64px)]">
        <Loader2 className="h-10 w-10 animate-spin text-gray-400" />
      </div>
    );
  }

  if (!repository) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-4">Repository not found</h2>
        <p className="text-gray-500 mb-6">
          The repository you're looking for doesn't exist or you don't have permission to view it.
        </p>
        <Link href="/">
          <Button>Go to Home</Button>
        </Link>
      </div>
    );
  }

  const isOwner = user && repository.userId === user.id;
  const filePathParts = path.split('/');
  const fileName = filePathParts[filePathParts.length - 1];
  const fileExtension = fileName.includes('.') ? fileName.split('.').pop()?.toLowerCase() : '';

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-4">
        <div className="flex items-center mb-4">
          <Link href={`/${params?.username}/${params?.repoName}`} className="text-blue-500 hover:underline flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to repository
          </Link>
        </div>
        
        <div className="flex items-center mb-2">
          <BookOpen className="text-gray-500 mr-2" size={16} />
          <Link href={`/${params?.username}`} className="text-blue-500 hover:underline mr-1">
            {params?.username}
          </Link>
          <span className="mx-1 text-gray-500">/</span>
          <Link href={`/${params?.username}/${params?.repoName}`} className="text-blue-500 hover:underline font-semibold">
            {repository.name}
          </Link>
          <span className="ml-2 text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
            {repository.isPrivate ? 'Private' : 'Public'}
          </span>
        </div>
      </div>

      <div className="border border-gray-200 rounded-md mb-6">
        <div className="bg-gray-50 border-b border-gray-200 p-3 flex justify-between items-center">
          <div className="text-gray-700 font-medium flex items-center overflow-x-auto whitespace-nowrap">
            {filePathParts.map((part, index) => (
              <div key={index} className="flex items-center">
                {index > 0 && <span className="mx-1 text-gray-400">/</span>}
                <Link
                  href={`/${params?.username}/${params?.repoName}/code/${filePathParts.slice(0, index + 1).join('/')}`}
                  className="text-blue-500 hover:underline"
                >
                  {part}
                </Link>
              </div>
            ))}
          </div>
          
          <div className="flex items-center">
            {isOwner && !isEditMode && (
              <Button variant="ghost" size="sm" onClick={handleEditClick}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" />
                </svg>
                Edit
              </Button>
            )}
          </div>
        </div>
        
        {fileError ? (
          <div className="p-4 text-red-500">
            Failed to load file: {(fileError as Error).message}
          </div>
        ) : (
          <>
            {isEditMode ? (
              <div>
                <CodeEditor
                  value={fileContent}
                  onChange={setFileContent}
                  language={fileExtension || 'plaintext'}
                />
                <div className="border-t border-gray-200 p-4">
                  <div className="mb-4">
                    <label htmlFor="commit-message" className="block text-sm font-medium text-gray-700 mb-1">
                      Commit message
                    </label>
                    <input 
                      type="text" 
                      id="commit-message"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                      value={commitMessage}
                      onChange={(e) => setCommitMessage(e.target.value)}
                      placeholder="Update file.ext"
                    />
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      className="bg-[#2ea44f] hover:bg-[#2c974b]"
                      onClick={handleSaveChanges}
                    >
                      Commit changes
                    </Button>
                    <Button variant="outline" onClick={handleCancelEdit}>
                      Cancel
                    </Button>
                  </div>
                </div>
              </div>
            ) : (
              <CodeViewer content={file?.content || ''} language={fileExtension || 'plaintext'} />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default RepositoryCodePage;
