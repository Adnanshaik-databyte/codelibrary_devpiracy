import { Link } from 'wouter';
import { Repository } from '@shared/schema';
import { Star, GitFork } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import LanguageIcon from '../icons/LanguageIcon';

interface RepositoryCardProps {
  repository: Repository;
}

const RepositoryCard = ({ repository }: RepositoryCardProps) => {
  // Determine the primary language for the repository (this would normally be determined from the files)
  const language = 'JavaScript'; // Placeholder, in real app would be determined from files

  // Get star count
  const { data: starData } = useQuery<{ count: number }>({
    queryKey: [`/api/repositories/${repository.id}/stars`],
    enabled: !!repository.id
  });

  // Get fork count
  const { data: forkData } = useQuery<{ count: number }>({
    queryKey: [`/api/repositories/${repository.id}/forks`],
    enabled: !!repository.id
  });

  return (
    <div className="border border-gray-200 rounded-md p-4">
      <div className="flex justify-between mb-2">
        <Link 
          href={`/${repository.userId}/${repository.name}`} 
          className="text-blue-500 font-medium hover:underline"
        >
          {repository.name}
        </Link>
        <span className="text-xs px-2 py-0.5 font-medium rounded-full bg-gray-100 border border-gray-200">
          {repository.isPrivate ? 'Private' : 'Public'}
        </span>
      </div>
      
      <p className="text-sm text-gray-500 mb-4 line-clamp-2 h-10">
        {repository.description || 'No description provided'}
      </p>
      
      <div className="flex items-center text-xs">
        {language && (
          <span className="flex items-center text-gray-600 mr-3">
            <LanguageIcon language={language} className="mr-1" />
            {language}
          </span>
        )}
        
        <span className="flex items-center text-gray-600 mr-3">
          <Star className="h-4 w-4 mr-1" />
          <span>{starData?.count || 0}</span>
        </span>
        
        <span className="flex items-center text-gray-600">
          <GitFork className="h-4 w-4 mr-1" />
          <span>{forkData?.count || 0}</span>
        </span>
      </div>
    </div>
  );
};

export default RepositoryCard;
