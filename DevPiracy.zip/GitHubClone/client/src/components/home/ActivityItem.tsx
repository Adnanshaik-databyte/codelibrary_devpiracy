import { Link } from 'wouter';
import { GitBranch, Star, FileCode } from 'lucide-react';

interface ActivityItemProps {
  activity: {
    id: number;
    type: 'branch' | 'star' | 'repository';
    user: string | undefined;
    repoName: string;
    description: string;
    time: string;
  };
}

const ActivityItem = ({ activity }: ActivityItemProps) => {
  const getIcon = () => {
    switch (activity.type) {
      case 'branch':
        return <GitBranch className="h-4 w-4 text-gray-500" />;
      case 'star':
        return <Star className="h-4 w-4 text-gray-500" />;
      case 'repository':
        return <FileCode className="h-4 w-4 text-gray-500" />;
      default:
        return <GitBranch className="h-4 w-4 text-gray-500" />;
    }
  };
  
  return (
    <div className="p-4">
      <div className="flex">
        <div className="mr-3 text-gray-500">
          {getIcon()}
        </div>
        <div>
          <div className="mb-1">
            {activity.user ? (
              <Link href={`/${activity.user}`} className="font-medium text-blue-500 hover:underline">
                {activity.user}
              </Link>
            ) : (
              <span className="font-medium">Anonymous</span>
            )}
            <span className="text-gray-500"> {activity.description}</span>
          </div>
          <div className="text-xs text-gray-500">{activity.time}</div>
        </div>
      </div>
    </div>
  );
};

export default ActivityItem;
