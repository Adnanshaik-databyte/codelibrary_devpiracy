import { FC } from 'react';

interface LanguageIconProps {
  language: string;
  className?: string;
}

const LanguageIcon: FC<LanguageIconProps> = ({ language, className = "" }) => {
  // Define language colors
  const getLanguageColor = (lang: string): string => {
    const colors: Record<string, string> = {
      javascript: '#f1e05a',
      typescript: '#3178c6',
      python: '#3572A5',
      java: '#b07219',
      go: '#00ADD8',
      ruby: '#701516',
      php: '#4F5D95',
      html: '#e34c26',
      css: '#563d7c',
      swift: '#F05138',
      rust: '#dea584',
      c: '#555555',
      'c++': '#f34b7d',
      'c#': '#178600',
      kotlin: '#A97BFF',
      dart: '#00B4AB',
      shell: '#89e051',
      powershell: '#012456',
      perl: '#0298c3',
      haskell: '#5e5086',
      lua: '#000080',
      scala: '#c22d40',
      clojure: '#db5855',
      elixir: '#6e4a7e',
      r: '#198CE7',
      groovy: '#e69f56',
    };
    
    return colors[lang.toLowerCase()] || '#8a8a8a';
  };

  return (
    <span 
      className={`inline-block w-3 h-3 rounded-full ${className}`}
      style={{ backgroundColor: getLanguageColor(language) }}
    ></span>
  );
};

export default LanguageIcon;
