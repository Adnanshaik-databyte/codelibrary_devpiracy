import { useState, useEffect, useRef } from 'react';
import { useTheme } from 'next-themes';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language?: string;
  height?: string;
}

const CodeEditor = ({
  value,
  onChange,
  language = 'plaintext',
  height = '400px'
}: CodeEditorProps) => {
  const { theme } = useTheme();
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const [lineCount, setLineCount] = useState<number>(0);

  useEffect(() => {
    const lines = value.split('\n');
    setLineCount(lines.length);
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    const lines = newValue.split('\n');
    setLineCount(lines.length);
  };

  const handleTab = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      
      const textarea = e.currentTarget;
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      
      const newValue = value.substring(0, start) + '  ' + value.substring(end);
      onChange(newValue);
      
      // Move cursor to after the inserted tab
      setTimeout(() => {
        textarea.selectionStart = start + 2;
        textarea.selectionEnd = start + 2;
      }, 0);
    }
  };

  const renderLineNumbers = () => {
    return Array.from({ length: lineCount }, (_, index) => (
      <div key={index + 1} className="text-right pr-2 text-gray-400 select-none">
        {index + 1}
      </div>
    ));
  };

  return (
    <div 
      className="font-mono text-sm border border-gray-200 rounded-md overflow-hidden"
      style={{ height }}
    >
      <div className="flex h-full">
        <div className="border-r border-gray-200 py-1 bg-gray-50 overflow-y-hidden">
          {renderLineNumbers()}
        </div>
        <textarea
          ref={editorRef}
          value={value}
          onChange={handleChange}
          onKeyDown={handleTab}
          className="w-full p-1 outline-none resize-none bg-white dark:bg-gray-900 text-gray-900 dark:text-white"
          style={{ 
            minHeight: height,
            lineHeight: '1.5',
            fontFamily: 'monospace',
            tabSize: 2
          }}
          spellCheck="false"
        />
      </div>
    </div>
  );
};

export default CodeEditor;
