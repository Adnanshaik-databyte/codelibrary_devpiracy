import { useState } from 'react';
import { Link } from 'wouter';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { User } from '@shared/schema';
import { useAuth } from '@/hooks/use-auth';
import { Mail, MapPin, Link as LinkIcon, Users } from 'lucide-react';

interface SidebarProps {
  profileUser: Omit<User, 'password'>;
  followers: number;
  following: number;
  isCurrentUser: boolean;
  isFollowing: boolean;
  onFollow: () => void;
  onUnfollow: () => void;
}

const Sidebar = ({ 
  profileUser, 
  followers, 
  following, 
  isCurrentUser,
  isFollowing,
  onFollow,
  onUnfollow
}: SidebarProps) => {
  const { user } = useAuth();
  const [isHovering, setIsHovering] = useState(false);

  const handleFollowClick = () => {
    if (isFollowing) {
      onUnfollow();
    } else {
      onFollow();
    }
  };

  return (
    <div className="w-full md:w-1/4 md:pr-6 mb-6 md:mb-0">
      <div className="mb-6">
        <div className="flex md:block items-center">
          <Avatar className="w-16 h-16 md:w-full md:h-auto md:max-w-[260px] rounded-full md:rounded-md">
            <AvatarImage src={profileUser.avatarUrl || ''} />
            <AvatarFallback className="text-4xl md:text-6xl">
              {profileUser.username.charAt(0).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          
          <div className="ml-4 md:ml-0 md:mt-3">
            <h1 className="text-2xl font-bold">{profileUser.username}</h1>
            <p className="text-gray-500">@{profileUser.username}</p>
          </div>
        </div>
        
        <div className="mt-4">
          <p className="text-gray-600 mb-3">{profileUser.bio || 'No bio provided'}</p>
          
          {isCurrentUser ? (
            <Button variant="outline" className="w-full mb-4">
              Edit profile
            </Button>
          ) : (
            <Button 
              variant={isFollowing ? "outline" : "default"}
              className="w-full mb-4"
              onClick={handleFollowClick}
              onMouseEnter={() => setIsHovering(true)}
              onMouseLeave={() => setIsHovering(false)}
            >
              {isFollowing ? 
                (isHovering ? "Unfollow" : "Following") : 
                "Follow"}
            </Button>
          )}
          
          <div className="flex items-center text-sm mb-3">
            <Users className="h-4 w-4 text-gray-500 mr-2" />
            <Link href={`/${profileUser.username}/followers`} className="text-gray-600 hover:text-blue-500">
              <span className="font-bold">{followers}</span> followers
            </Link>
            <span className="mx-1">·</span>
            <Link href={`/${profileUser.username}/following`} className="text-gray-600 hover:text-blue-500">
              <span className="font-bold">{following}</span> following
            </Link>
          </div>
          
          {profileUser.location && (
            <div className="flex items-center text-sm mb-1">
              <MapPin className="h-4 w-4 text-gray-500 mr-2" />
              <span className="text-gray-600">{profileUser.location}</span>
            </div>
          )}
          
          {profileUser.email && (
            <div className="flex items-center text-sm mb-1">
              <Mail className="h-4 w-4 text-gray-500 mr-2" />
              <a href={`mailto:${profileUser.email}`} className="text-blue-500 hover:underline">
                {profileUser.email}
              </a>
            </div>
          )}
          
          {profileUser.website && (
            <div className="flex items-center text-sm">
              <LinkIcon className="h-4 w-4 text-gray-500 mr-2" />
              <a 
                href={profileUser.website.startsWith('http') ? profileUser.website : `https://${profileUser.website}`} 
                className="text-blue-500 hover:underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                {profileUser.website}
              </a>
            </div>
          )}
        </div>
      </div>

      {/* Organizations would go here */}
    </div>
  );
};

export default Sidebar;
