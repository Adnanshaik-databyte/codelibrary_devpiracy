import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  GitPullRequest, 
  CircleAlert, 
  Search, 
  Plus, 
  Bell, 
  Menu, 
  X, 
  LogOut, 
  Settings, 
  User, 
  Star, 
  GitFork
} from 'lucide-react';
import { FaGithub, FaPaw } from 'react-icons/fa';

const Header = () => {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-github-dark text-white px-4 py-3">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center w-full md:w-auto justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-white font-bold text-xl flex items-center">
              <FaPaw className="text-2xl mr-2" />
              DevPiracy
            </Link>
            <div className="relative ml-4 hidden md:block w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <form onSubmit={(e) => {
                e.preventDefault();
                const search = e.currentTarget.search.value;
                if (search.trim()) {
                  window.location.href = `/?q=${encodeURIComponent(search.trim())}`;
                }
              }}>
                <Input 
                  name="search"
                  type="text" 
                  placeholder="Search or jump to..." 
                  className="w-full bg-github-dark border border-gray-600 rounded-md py-1 pl-10 pr-8 text-sm text-white focus:outline-none focus:ring-2 focus:ring-white"
                />
              </form>
              <div className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gray-700 text-xs px-1 rounded">/</div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="md:hidden text-white" 
            onClick={toggleMobileMenu}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>
        
        <nav className={`${mobileMenuOpen ? 'flex' : 'hidden'} md:flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4 w-full md:w-auto pt-4 md:pt-0`}>
          <Link href="/pulls" className="text-white hover:text-gray-300 py-2 flex items-center">
            <GitPullRequest className="h-4 w-4 mr-1 md:mr-0 md:hidden lg:block" />
            <span className="md:hidden lg:inline">Pull requests</span>
          </Link>
          <Link href="/issues" className="text-white hover:text-gray-300 py-2 flex items-center">
            <CircleAlert className="h-4 w-4 mr-1 md:mr-0 md:hidden lg:block" />
            <span className="md:hidden lg:inline">Issues</span>
          </Link>
          <Link href="/explore" className="text-white hover:text-gray-300 py-2">
            Explore
          </Link>
          
          {user ? (
            <>
              <div className="relative">
                <Button variant="ghost" size="sm" className="text-white hover:text-gray-300 p-0 h-8 w-8">
                  <Bell />
                </Button>
              </div>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-white hover:text-gray-300 p-0 h-8 w-8">
                    <Plus />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem>
                    <Link href="/new" className="w-full flex">New repository</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>Import repository</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>New issue</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-white p-1 h-8 flex items-center">
                    <Avatar className="h-5 w-5">
                      <AvatarImage src={user.avatarUrl || ''} />
                      <AvatarFallback>{user.username.charAt(0).toUpperCase()}</AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <div className="px-2 py-1.5 text-sm">
                    Signed in as <strong>{user.username}</strong>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href={`/${user.username}`} className="w-full flex items-center">
                      <User className="mr-2 h-4 w-4" /> Your profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href={`/${user.username}?tab=repositories`} className="w-full flex items-center">
                      <GitFork className="mr-2 h-4 w-4" /> Your repositories
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href={`/${user.username}?tab=stars`} className="w-full flex items-center">
                      <Star className="mr-2 h-4 w-4" /> Your stars
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href="/settings" className="w-full flex items-center">
                      <Settings className="mr-2 h-4 w-4" /> Settings
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Link href="/auth">
                <Button variant="ghost" className="text-white hover:text-gray-300">
                  Sign in
                </Button>
              </Link>
              <Link href="/auth">
                <Button variant="outline" className="text-white border-gray-400 hover:border-white hover:bg-transparent">
                  Sign up
                </Button>
              </Link>
            </div>
          )}
        </nav>
      </div>
      
      {/* Mobile Search (visible on small screens) */}
      <div className="md:hidden pt-3 pb-2">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-gray-400" />
          </div>
          <form onSubmit={(e) => {
            e.preventDefault();
            const search = e.currentTarget.search.value;
            if (search.trim()) {
              window.location.href = `/?q=${encodeURIComponent(search.trim())}`;
            }
          }}>
            <Input 
              name="search"
              type="text" 
              placeholder="Search or jump to..." 
              className="w-full bg-github-dark border border-gray-600 rounded-md py-1 pl-10 pr-8 text-sm text-white focus:outline-none focus:ring-2 focus:ring-white"
            />
          </form>
          <div className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gray-700 text-xs px-1 rounded">/</div>
        </div>
      </div>
    </header>
  );
};

export default Header;
