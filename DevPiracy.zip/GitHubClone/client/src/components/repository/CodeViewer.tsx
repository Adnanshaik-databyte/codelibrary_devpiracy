import { useEffect, useState } from 'react';
import { useTheme } from 'next-themes';

interface CodeViewerProps {
  content: string;
  language: string;
}

const CodeViewer = ({ content, language }: CodeViewerProps) => {
  const { theme } = useTheme();
  const [highlightedCode, setHighlightedCode] = useState<string>(content);
  const [lineCount, setLineCount] = useState<number>(0);

  useEffect(() => {
    const lines = content.split('\n');
    setLineCount(lines.length);
    
    // Basic syntax highlighting for common languages
    if (['js', 'javascript', 'ts', 'typescript'].includes(language.toLowerCase())) {
      let highlighted = content
        .replace(/\b(const|let|var|function|return|if|else|for|while|switch|case|break|default|class|import|export|from|as|async|await|try|catch|throw|new|this)\b/g, '<span class="syntax-js-keyword">$1</span>')
        .replace(/"([^"]*)"/g, '<span class="syntax-js-string">"$1"</span>')
        .replace(/'([^']*)'/g, '<span class="syntax-js-string">\'$1\'</span>')
        .replace(/\/\/(.*)/g, '<span class="syntax-js-comment">//$1</span>')
        .replace(/\/\*([\s\S]*?)\*\//g, '<span class="syntax-js-comment">/*$1*/</span>');
      setHighlightedCode(highlighted);
    } else if (['jsx', 'tsx'].includes(language.toLowerCase())) {
      let highlighted = content
        .replace(/\b(const|let|var|function|return|if|else|for|while|switch|case|break|default|class|import|export|from|as|async|await|try|catch|throw|new|this)\b/g, '<span class="syntax-js-keyword">$1</span>')
        .replace(/"([^"]*)"/g, '<span class="syntax-js-string">"$1"</span>')
        .replace(/'([^']*)'/g, '<span class="syntax-js-string">\'$1\'</span>')
        .replace(/\/\/(.*)/g, '<span class="syntax-js-comment">//$1</span>')
        .replace(/\/\*([\s\S]*?)\*\//g, '<span class="syntax-js-comment">/*$1*/</span>')
        .replace(/(<\/?[a-zA-Z][\w.-]*)\b/g, '<span class="syntax-jsx-tag">$1</span>');
      setHighlightedCode(highlighted);
    } else if (['html', 'xml'].includes(language.toLowerCase())) {
      let highlighted = content
        .replace(/(<\/?[a-zA-Z][\w.-]*)\b/g, '<span class="syntax-html-tag">$1</span>')
        .replace(/([a-zA-Z][\w.-]*)(?=\s*=\s*["'])/g, '<span class="syntax-html-attr">$1</span>')
        .replace(/"([^"]*)"/g, '<span class="syntax-html-string">"$1"</span>')
        .replace(/'([^']*)'/g, '<span class="syntax-html-string">\'$1\'</span>')
        .replace(/<!--([\s\S]*?)-->/g, '<span class="syntax-html-comment"><!--$1--></span>');
      setHighlightedCode(highlighted);
    } else if (['css', 'scss', 'sass'].includes(language.toLowerCase())) {
      let highlighted = content
        .replace(/([a-zA-Z-][\w-]*)(?=\s*:)/g, '<span class="syntax-css-property">$1</span>')
        .replace(/:[^;]*;/g, (match) => {
          return ':' + '<span class="syntax-css-value">' + match.slice(1, -1) + '</span>' + ';';
        })
        .replace(/\/\*([\s\S]*?)\*\//g, '<span class="syntax-css-comment">/*$1*/</span>');
      setHighlightedCode(highlighted);
    } else {
      setHighlightedCode(content);
    }
  }, [content, language]);

  const renderLineNumbers = () => {
    return Array.from({ length: lineCount }, (_, index) => (
      <div key={index + 1} className="text-right pr-4 text-gray-400 select-none">
        {index + 1}
      </div>
    ));
  };

  const renderCode = () => {
    return content.split('\n').map((line, index) => (
      <div key={index} className="px-4">
        {line || ' '}
      </div>
    ));
  };

  return (
    <div className="font-mono text-sm overflow-auto">
      <style jsx>{`
        .syntax-js-keyword { color: #cf222e; }
        .syntax-js-string { color: #0a3069; }
        .syntax-js-comment { color: #6e7781; }
        
        .syntax-jsx-tag { color: #22863a; }
        
        .syntax-html-tag { color: #22863a; }
        .syntax-html-attr { color: #6f42c1; }
        .syntax-html-string { color: #0a3069; }
        .syntax-html-comment { color: #6e7781; }
        
        .syntax-css-property { color: #6f42c1; }
        .syntax-css-value { color: #0550ae; }
        .syntax-css-comment { color: #6e7781; }
        
        .dark .syntax-js-keyword { color: #ff7b72; }
        .dark .syntax-js-string { color: #a5d6ff; }
        .dark .syntax-js-comment { color: #8b949e; }
        
        .dark .syntax-jsx-tag { color: #7ee787; }
        
        .dark .syntax-html-tag { color: #7ee787; }
        .dark .syntax-html-attr { color: #d2a8ff; }
        .dark .syntax-html-string { color: #a5d6ff; }
        .dark .syntax-html-comment { color: #8b949e; }
        
        .dark .syntax-css-property { color: #d2a8ff; }
        .dark .syntax-css-value { color: #79c0ff; }
        .dark .syntax-css-comment { color: #8b949e; }
      `}</style>
      <div className="border-b border-gray-200 px-4 py-2 bg-gray-50 text-gray-500 text-xs">
        {lineCount} {lineCount === 1 ? 'line' : 'lines'} · {content.length} {content.length === 1 ? 'byte' : 'bytes'}
      </div>
      <div className="relative">
        <div className="flex">
          <div className="border-r border-gray-200 py-2 bg-gray-50">
            {renderLineNumbers()}
          </div>
          <div className="overflow-x-auto w-full py-2">
            {content.length > 100000 ? (
              <div className="px-4 text-gray-700">
                {renderCode()}
              </div>
            ) : (
              <div 
                className="px-4"
                dangerouslySetInnerHTML={{ __html: highlightedCode.split('\n').join('\n<br>') }} 
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodeViewer;
