import { Link } from 'wouter';
import { Commit as CommitType } from '@shared/schema';

interface CommitProps {
  commit: CommitType;
  username: string | undefined;
}

const Commit = ({ commit, username }: CommitProps) => {
  // Format date to readable format
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    // If less than a day, show relative time
    if (diff < 24 * 60 * 60 * 1000) {
      const hours = Math.floor(diff / (60 * 60 * 1000));
      if (hours < 1) {
        const minutes = Math.floor(diff / (60 * 1000));
        return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
      }
      return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    }
    
    // If less than a week, show day of week
    if (diff < 7 * 24 * 60 * 60 * 1000) {
      return date.toLocaleDateString('en-US', { weekday: 'long' });
    }
    
    // Otherwise show full date
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Generate a random hash-like string for demo purposes
  const generateCommitHash = (id: number) => {
    const characters = '0123456789abcdef';
    let hash = '';
    // Use the commit ID as part of the hash for consistency
    const seed = id.toString();
    
    for (let i = 0; i < 7; i++) {
      const index = (seed.charCodeAt(i % seed.length) + i) % characters.length;
      hash += characters[index];
    }
    
    return hash;
  };

  return (
    <div className="bg-gray-50 border-b border-gray-200 p-3 flex justify-between items-center">
      <div className="flex items-center">
        {/* User avatar - use first letter of username as fallback */}
        <div className="w-5 h-5 rounded-full bg-gray-300 flex items-center justify-center text-xs text-gray-700 mr-2">
          {username ? username.charAt(0).toUpperCase() : 'U'}
        </div>
        
        <Link 
          href={`/${username}`} 
          className="text-blue-500 hover:underline font-medium"
        >
          {username}
        </Link>
        
        <span className="text-gray-500 ml-2">{commit.message}</span>
        
        <Link 
          href={`/${username}/${commit.repositoryId}/commit/${commit.id}`}
          className="text-gray-500 hover:text-blue-500 ml-2 text-xs"
        >
          {generateCommitHash(commit.id)}
        </Link>
      </div>
      
      <div className="text-gray-500 text-sm">
        {formatDate(commit.createdAt)}
      </div>
    </div>
  );
};

export default Commit;
