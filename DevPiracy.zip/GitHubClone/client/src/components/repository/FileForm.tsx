import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';

interface FileFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  repositoryId: number;
  username: string;
  repoName: string;
}

const FileForm = ({ open, onOpenChange, repositoryId, username, repoName }: FileFormProps) => {
  const { toast } = useToast();
  const [fileName, setFileName] = useState('');
  const [fileContent, setFileContent] = useState('');
  const [commitMessage, setCommitMessage] = useState('');

  const createFileMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/repositories/${repositoryId}/files`, {
        path: fileName,
        content: fileContent,
        commitMessage
      });
    },
    onSuccess: () => {
      toast({
        title: 'Success',
        description: `File "${fileName}" has been created`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repositoryId}/files`] });
      queryClient.invalidateQueries({ queryKey: [`/api/repositories/${repositoryId}/commits`] });
      
      // Reset form and close dialog
      setFileName('');
      setFileContent('');
      setCommitMessage('');
      onOpenChange(false);
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: `Failed to create file: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fileName) {
      toast({
        title: 'Error',
        description: 'File name is required',
        variant: 'destructive',
      });
      return;
    }
    
    createFileMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Create new file</DialogTitle>
          <DialogDescription>
            Add a new file to repository "{repoName}"
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="fileName">File name</Label>
            <Input
              id="fileName"
              placeholder="e.g. README.md"
              value={fileName}
              onChange={(e) => setFileName(e.target.value)}
              disabled={createFileMutation.isPending}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="fileContent">File content</Label>
            <Textarea
              id="fileContent"
              placeholder="Enter file content..."
              rows={10}
              value={fileContent}
              onChange={(e) => setFileContent(e.target.value)}
              disabled={createFileMutation.isPending}
              className="font-mono text-sm"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="commitMessage">Commit message</Label>
            <Input
              id="commitMessage"
              placeholder="e.g. Add README file"
              value={commitMessage}
              onChange={(e) => setCommitMessage(e.target.value)}
              disabled={createFileMutation.isPending}
            />
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={createFileMutation.isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={createFileMutation.isPending}>
              {createFileMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Creating...
                </>
              ) : 'Create file'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default FileForm;