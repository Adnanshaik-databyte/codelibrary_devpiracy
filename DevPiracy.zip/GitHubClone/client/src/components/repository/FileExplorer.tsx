import { Link } from 'wouter';
import { FileIcon, FolderIcon, ChevronRight } from 'lucide-react';
import { File } from '@shared/schema';

interface FileExplorerProps {
  files: File[];
  repoName: string;
  username: string;
}

const FileExplorer = ({ files, repoName, username }: FileExplorerProps) => {
  // Group files by directory
  const getFileHierarchy = (files: File[]) => {
    const rootFiles: File[] = [];
    const directories: Record<string, File[]> = {};
    
    // Sort files by path
    const sortedFiles = [...files].sort((a, b) => a.path.localeCompare(b.path));
    
    sortedFiles.forEach(file => {
      const pathParts = file.path.split('/');
      
      if (pathParts.length === 1) {
        // This is a file in the root directory
        rootFiles.push(file);
      } else {
        // This is a file in a subdirectory
        const dirPath = pathParts.slice(0, -1).join('/');
        if (!directories[dirPath]) {
          directories[dirPath] = [];
        }
        directories[dirPath].push(file);
      }
    });
    
    return { rootFiles, directories };
  };
  
  const { rootFiles, directories } = getFileHierarchy(files);
  
  // Get directories at the top level
  const topLevelDirs = Object.keys(directories)
    .filter(dir => !dir.includes('/'))
    .sort();
  
  // Get modification time 
  const getTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return 'just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} minute${minutes !== 1 ? 's' : ''} ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours !== 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    if (days < 30) return `${days} day${days !== 1 ? 's' : ''} ago`;
    const months = Math.floor(days / 30);
    if (months < 12) return `${months} month${months !== 1 ? 's' : ''} ago`;
    const years = Math.floor(months / 12);
    return `${years} year${years !== 1 ? 's' : ''} ago`;
  };

  return (
    <div className="w-full">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Name
            </th>
            <th scope="col" className="hidden md:table-cell px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Last commit message
            </th>
            <th scope="col" className="hidden md:table-cell px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
              Last updated
            </th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {/* Top level directories */}
          {topLevelDirs.map(dir => (
            <tr key={`dir-${dir}`} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <Link 
                  href={`/${username}/${repoName}/code/${dir}`}
                  className="flex items-center text-blue-500 hover:underline"
                >
                  <FolderIcon className="h-5 w-5 mr-2 text-gray-400" />
                  <span>{dir}</span>
                  <ChevronRight className="h-4 w-4 ml-1 text-gray-400" />
                </Link>
              </td>
              <td className="hidden md:table-cell px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {directories[dir][0].lastCommitId ? "Updated files" : "Added directory"}
              </td>
              <td className="hidden md:table-cell px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {getTimeAgo(directories[dir][0].createdAt)}
              </td>
            </tr>
          ))}
          
          {/* Root files */}
          {rootFiles.map(file => (
            <tr key={file.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <Link 
                  href={`/${username}/${repoName}/code/${file.path}`}
                  className="flex items-center text-blue-500 hover:underline"
                >
                  <FileIcon className="h-5 w-5 mr-2 text-gray-400" />
                  <span>{file.path}</span>
                </Link>
              </td>
              <td className="hidden md:table-cell px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {file.lastCommitId ? "Updated file" : "Added file"}
              </td>
              <td className="hidden md:table-cell px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                {getTimeAgo(file.createdAt)}
              </td>
            </tr>
          ))}
          
          {rootFiles.length === 0 && topLevelDirs.length === 0 && (
            <tr>
              <td colSpan={3} className="px-6 py-8 text-center text-gray-500">
                This repository is empty. Add some files to get started.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FileExplorer;
